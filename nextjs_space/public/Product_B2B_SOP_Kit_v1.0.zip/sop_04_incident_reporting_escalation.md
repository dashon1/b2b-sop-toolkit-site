# SOP-04: Incident Reporting and Escalation

**Document ID:** SOP-04-IRE  
**Version:** 1.0  
**Effective Date:** _______________  
**Last Reviewed:** _______________  
**Document Owner:** Chief Information Security Officer (CISO)  
**Classification:** Confidential — Internal Use Only

---

## 1. Purpose

This Standard Operating Procedure establishes a uniform, timely, and well-documented process for reporting, classifying, escalating, and tracking security incidents, compliance events, and operational disruptions. It ensures that all incidents are captured, appropriately triaged, escalated to the correct decision-makers, and resolved within defined service levels to meet regulatory obligations and minimize organizational risk.

## 2. Scope

This SOP applies to:

- All security incidents (attempted or successful unauthorized access, malware, phishing, social engineering)
- Compliance events (policy violations, regulatory non-compliance findings, audit exceptions)
- Operational disruptions (system outages, data corruption, service degradation)
- Physical security incidents (unauthorized facility access, theft, environmental hazards)
- Third-party incidents affecting organizational data or operations
- All employees, contractors, vendors, and visitors

## 3. Definitions

| Term | Definition |
|------|-----------|
| **Incident** | Any event that has the potential to compromise the confidentiality, integrity, or availability of information assets, violate policies or regulations, or disrupt operations |
| **Event** | An observable occurrence in a system, network, or environment that may or may not constitute an incident |
| **Escalation** | The process of raising an incident to a higher authority or specialized team for resolution |
| **First Responder** | The first member of the security or operations team to assess and triage a reported incident |
| **Incident Commander** | The individual with overall authority for managing a specific incident through resolution |
| **Root Cause** | The fundamental underlying reason that an incident occurred |

## 4. Responsibilities

| Role | Responsibilities |
|------|-----------------|
| **All Personnel** | Report suspected incidents immediately; cooperate with investigations; preserve evidence |
| **Security Operations Center (SOC)** | Receives reports; performs initial triage; classifies severity; assigns first responders |
| **First Responder** | Assesses and validates the incident; initiates containment; documents initial findings |
| **Incident Commander** | Manages incident resolution; coordinates resources; makes escalation decisions; authorizes communications |
| **CISO** | Receives escalations for High and Critical incidents; authorizes external notifications; approves corrective actions |
| **Legal Counsel** | Advises on regulatory notification obligations; manages law enforcement engagement |
| **Compliance Officer** | Tracks incidents for compliance reporting; ensures documentation meets audit requirements |
| **Department Managers** | Support incident investigation within their areas; implement departmental corrective actions |
| **Executive Leadership** | Receives briefings on Critical incidents; approves resource allocation for major incidents |

## 5. Procedures

### 5.1 Incident Reporting

**Requirement:** All suspected incidents must be reported within **1 hour** of discovery, regardless of severity.

| Step | Action | Responsible Party | Documentation |
|------|--------|------------------|---------------|
| 1.1 | Identify a suspected incident through: monitoring alerts, direct observation, user report, third-party notification, or audit finding | Any Personnel | N/A |
| 1.2 | Do NOT attempt to investigate or remediate independently — report immediately | Reporting Party | N/A |
| 1.3 | Report via one of the approved channels: (a) Incident Reporting Hotline: [Insert Number]; (b) Secure email: [Insert Address]; (c) Incident Reporting Portal: [Insert URL]; (d) Direct notification to a supervisor or Security team member | Reporting Party | Report submission confirmation |
| 1.4 | Provide the following information: Date/time of discovery; description of the event; systems, data, or facilities affected; actions taken (if any); contact information for follow-up | Reporting Party | Initial Incident Report |
| 1.5 | SOC logs the report in the Incident Tracking System and assigns a unique incident ID | SOC | Incident ticket created |

**Note:** The organization maintains a strict non-retaliation policy for good-faith incident reporting.

### 5.2 Incident Triage and Classification

**Timeline:** Within 30 minutes of report receipt

| Step | Action | Responsible Party | Documentation |
|------|--------|------------------|---------------|
| 2.1 | SOC validates the report: confirm it is a genuine incident (not a false positive or duplicate) | SOC Analyst | Validation notes in ticket |
| 2.2 | Classify the incident category (see Section 5.3) | SOC Analyst | Category assignment |
| 2.3 | Assign severity level using the Severity Matrix (see Section 6) | SOC Analyst | Severity assignment |
| 2.4 | Assign a First Responder based on incident category and required expertise | SOC | First Responder assignment |
| 2.5 | Initiate the escalation path based on severity (see Section 5.4) | SOC | Escalation initiation log |

### 5.3 Incident Categories

| Category | Examples |
|----------|---------|
| **SEC — Security** | Unauthorized access, malware, ransomware, phishing, DDoS, credential compromise |
| **DAT — Data** | Data breach, data loss, unauthorized disclosure, data corruption |
| **SYS — System** | System outage, service degradation, infrastructure failure, configuration error |
| **PHY — Physical** | Unauthorized facility access, theft, vandalism, environmental hazard (fire, flood) |
| **COM — Compliance** | Policy violation, regulatory non-compliance, failed audit control, unauthorized process change |
| **VEN — Vendor/Third-Party** | Vendor breach affecting organizational data, SLA failure, supply chain compromise |
| **HUM — Human** | Social engineering, insider threat, negligent data handling |

### 5.4 Escalation Matrix

| Severity | Classification Criteria | Response Time | Escalation Path | Status Updates |
|----------|------------------------|---------------|-----------------|----------------|
| **P1 — Critical** | Active data breach; system-wide outage; ransomware; PHI/PII exfiltration; imminent regulatory violation | Immediate | SOC → Incident Commander → CISO → Legal → Executive Leadership (within 30 min) | Every 30 minutes |
| **P2 — High** | Confirmed unauthorized access; significant data exposure; compliance violation; major service degradation | Within 1 hour | SOC → Incident Commander → CISO → Legal (within 2 hours) | Every 1 hour |
| **P3 — Medium** | Suspected unauthorized access; minor policy violation; limited service impact; phishing attempt (not successful) | Within 4 hours | SOC → First Responder → Department Manager (within 4 hours) | Every 4 hours |
| **P4 — Low** | Failed login attempts; minor configuration drift; informational security events; non-sensitive policy deviation | Within 24 hours | SOC → First Responder (within 24 hours) | Daily |

### 5.5 Incident Response and Resolution

| Step | Action | Responsible Party | Documentation |
|------|--------|------------------|---------------|
| 5.1 | First Responder performs an initial assessment and confirms the severity classification | First Responder | Assessment notes |
| 5.2 | Implement immediate containment measures to prevent further damage or exposure | First Responder / IT Security | Containment action log |
| 5.3 | For P1/P2 incidents, the Incident Commander convenes the Incident Response Team and establishes a communication bridge | Incident Commander | IRT activation log; bridge details |
| 5.4 | Conduct investigation to determine root cause, scope, and impact | IRT / IT Security | Investigation notes |
| 5.5 | Implement remediation: eradicate the threat, restore affected systems, apply corrective controls | IT Security / IT Operations | Remediation action log |
| 5.6 | Verify remediation effectiveness: confirm threat is eliminated and systems are operating normally | IT Security | Verification report |
| 5.7 | For incidents involving regulatory notifications, coordinate with Legal and Compliance per SOP-01 | Legal / Compliance | Notification records |
| 5.8 | Close the incident ticket with full resolution details and obtain Incident Commander sign-off | Incident Commander | Closed incident ticket |

### 5.6 Post-Incident Activities

| Step | Action | Responsible Party | Timeline | Documentation |
|------|--------|------------------|----------|---------------|
| 6.1 | Conduct a post-incident review for all P1 and P2 incidents (recommended for P3) | Incident Commander | Within 10 business days of closure | Post-Incident Review Report |
| 6.2 | Identify root causes, contributing factors, and process gaps | IRT Members | During review | Root Cause Analysis |
| 6.3 | Develop corrective and preventive actions with assigned owners and deadlines | Incident Commander | During review | Corrective Action Plan |
| 6.4 | Track corrective actions to completion | Compliance Officer | Per assigned deadlines | Action tracking log |
| 6.5 | Update SOPs, policies, and training materials based on lessons learned | Document Owners | Within 30 days | Updated documents |
| 6.6 | Incorporate incident data into the organization's risk register and threat intelligence | Compliance / Security | Within 30 days | Updated risk register |

## 6. Severity Matrix — Detailed Criteria

| Factor | P1 — Critical | P2 — High | P3 — Medium | P4 — Low |
|--------|--------------|-----------|-------------|----------|
| **Data Impact** | PHI/PII of >500 individuals confirmed compromised | PHI/PII of <500 individuals or sensitive financial data exposed | Potential data exposure; no confirmed compromise | No data impact |
| **System Impact** | Critical systems down; organization-wide impact | Major system degraded; department-wide impact | Minor system issue; limited user impact | Cosmetic or informational issue |
| **Regulatory Impact** | Mandatory breach notification triggered | Potential regulatory implications requiring legal review | Minor policy deviation; no regulatory threshold met | No regulatory impact |
| **Business Impact** | Revenue-impacting; client-facing service outage; contractual SLA breach | Significant operational disruption; internal SLA breach | Minor operational inconvenience | Negligible business impact |
| **Active Threat** | Threat actor actively present; ongoing exfiltration | Confirmed past unauthorized access; no active threat | Suspicious activity under investigation | No threat identified |

## 7. Communication Protocols

| Audience | P1 — Critical | P2 — High | P3 — Medium | P4 — Low |
|----------|--------------|-----------|-------------|----------|
| SOC / First Responder | Immediate | Immediate | Within 4 hours | Within 24 hours |
| Incident Commander | Within 15 minutes | Within 1 hour | If escalated | N/A |
| CISO | Within 30 minutes | Within 2 hours | Weekly summary | Monthly summary |
| Legal Counsel | Within 30 minutes | Within 4 hours | If needed | N/A |
| Executive Leadership | Within 1 hour | Within 4 hours | Weekly summary | N/A |
| Affected Business Units | Within 2 hours | Within 4 hours | As needed | N/A |
| External Parties | Per legal/regulatory requirements | Per legal determination | N/A | N/A |

## 8. Documentation Requirements

- [ ] Initial Incident Report (for every reported incident)
- [ ] Incident Ticket with full lifecycle documentation
- [ ] Severity Classification and Category Assignment
- [ ] Escalation Records (who was notified, when, and how)
- [ ] Containment and Remediation Action Logs
- [ ] Investigation Notes and Findings
- [ ] Post-Incident Review Report (P1/P2 mandatory)
- [ ] Root Cause Analysis
- [ ] Corrective Action Plan with tracking
- [ ] Communication logs (all internal and external notifications)
- [ ] Incident metrics (MTTD, MTTC, MTTR)

**Retention Period:** All incident records must be retained for a minimum of **6 years** or as required by applicable regulation.

## 9. Key Performance Indicators

| Metric | Target |
|--------|--------|
| Incident reporting compliance (within 1 hour) | 100% |
| Triage completion (within 30 minutes of receipt) | 95% |
| P1 escalation to CISO (within 30 minutes) | 100% |
| Post-incident review completion (P1/P2) | 100% within 10 business days |
| Corrective action closure rate | 100% within assigned deadlines |
| False positive rate | < 20% |

## 10. Related Documents

- SOP-01: Data Breach Response
- SOP-02: Access Control and Authentication
- Information Security Policy
- Business Continuity Plan
- Incident Response Plan
- Vendor Management Policy

## 11. Review Schedule

| Review Activity | Frequency | Responsible Party |
|----------------|-----------|------------------|
| Full SOP review and update | Annually | CISO / Compliance Officer |
| Escalation path and contact list verification | Quarterly | SOC Manager |
| Incident response tabletop exercise | Semi-annually | CISO / Incident Commander |
| Incident metrics review | Monthly | SOC Manager / CISO |
| Training on reporting procedures | Annually (all staff) | HR / Security Awareness Team |

## 12. Revision History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | _____________ | _____________ | Initial release |

## 13. Approval

| Role | Name | Signature | Date |
|------|------|-----------|------|
| CISO | | | |
| COO | | | |
| Compliance Officer | | | |
| Legal Counsel | | | |
