# Compliance Calendar Template: Annual Compliance Activities

**Document ID:** CAL-COMP-001  
**Version:** 1.0  
**Calendar Year:** _______________  
**Document Owner:** Compliance Officer  
**Classification:** Confidential — Internal Use Only

---

## Purpose

This compliance calendar provides a month-by-month schedule of all recurring compliance activities, reviews, audits, assessments, and deadlines required to maintain regulatory compliance throughout the year. Customize this calendar based on your applicable regulations (HIPAA, SOC 2, GLBA, legal industry requirements) and organizational review cycles.

---

## Instructions

1. Review each activity and mark its applicability to your organization
2. Assign responsible owners for each activity
3. Track completion status throughout the year
4. Use this calendar as a planning tool — schedule activities in your organizational calendar system
5. Review and update this calendar annually (in December for the following year)

---

## Annual Calendar Overview

### January

| Activity | Category | Applicable Frameworks | Owner | Status |
|----------|----------|----------------------|-------|--------|
| Annual compliance program review and planning | Governance | All | Compliance Officer | ☐ Complete ☐ Pending |
| Update Compliance Calendar for the new year | Governance | All | Compliance Officer | ☐ Complete ☐ Pending |
| Q4 (prior year) compliance KPI review and reporting | Monitoring | All | Compliance Officer | ☐ Complete ☐ Pending |
| Quarterly access review (Q4 prior year) — if not completed in December | Access Control | SOC 2, HIPAA, GLBA | IT Security / IAM | ☐ Complete ☐ Pending |
| Annual privacy notice distribution (if required) | Privacy | GLBA | Privacy Officer | ☐ Complete ☐ Pending |
| Verify cyber insurance policy renewal and coverage adequacy | Risk Management | All | Legal / Risk | ☐ Complete ☐ Pending |

### February

| Activity | Category | Applicable Frameworks | Owner | Status |
|----------|----------|----------------------|-------|--------|
| **HIPAA breach log submission to HHS** (for breaches <500 in prior calendar year — **due within 60 days of calendar year end**) | Regulatory Filing | HIPAA | Privacy Officer | ☐ Complete ☐ Pending |
| Annual security awareness training campaign launch | Training | All | HR / IT Security | ☐ Complete ☐ Pending |
| Annual HIPAA training launch (for PHI access roles) | Training | HIPAA | Privacy Officer / HR | ☐ Complete ☐ Pending |
| Begin annual risk assessment planning | Risk Management | All | CISO / Compliance | ☐ Complete ☐ Pending |
| Review and update emergency contact and escalation lists | Operations | All | Compliance / IT Security | ☐ Complete ☐ Pending |

### March

| Activity | Category | Applicable Frameworks | Owner | Status |
|----------|----------|----------------------|-------|--------|
| Q1 quarterly access review | Access Control | SOC 2, HIPAA, GLBA | IT Security / IAM | ☐ Complete ☐ Pending |
| Q1 incident metrics review | Monitoring | All | CISO / SOC Manager | ☐ Complete ☐ Pending |
| Annual risk assessment execution | Risk Management | All | CISO / Compliance | ☐ Complete ☐ Pending |
| Semi-annual physical security walkthrough | Physical Security | SOC 2, HIPAA | Facilities | ☐ Complete ☐ Pending |
| Annual training completion deadline (all employees must complete by end of Q1) | Training | All | HR / Compliance | ☐ Complete ☐ Pending |
| Verify all policy acknowledgments collected for the year | Governance | All | HR / Compliance | ☐ Complete ☐ Pending |

### April

| Activity | Category | Applicable Frameworks | Owner | Status |
|----------|----------|----------------------|-------|--------|
| Annual risk assessment report finalized and presented to leadership | Risk Management | All | CISO / Compliance | ☐ Complete ☐ Pending |
| Risk register update based on assessment findings | Risk Management | All | CISO / Compliance | ☐ Complete ☐ Pending |
| Semi-annual breach response tabletop exercise | Incident Response | HIPAA, SOC 2 | Breach Coordinator / CISO | ☐ Complete ☐ Pending |
| Q1 compliance KPI review and reporting | Monitoring | All | Compliance Officer | ☐ Complete ☐ Pending |
| Review Master Retention Schedule for regulatory changes | Records | All | Compliance / Legal | ☐ Complete ☐ Pending |

### May

| Activity | Category | Applicable Frameworks | Owner | Status |
|----------|----------|----------------------|-------|--------|
| Annual penetration test (schedule/execute) | Security Testing | SOC 2, GLBA, PCI DSS | IT Security (external firm) | ☐ Complete ☐ Pending |
| Semi-annual vulnerability assessment (if not continuous) | Security Testing | SOC 2, GLBA | IT Security | ☐ Complete ☐ Pending |
| Annual vendor risk reassessment — Critical tier vendors | Vendor Management | All | Compliance / Procurement | ☐ Complete ☐ Pending |
| Review and update BAA/DPA inventory | Vendor Management | HIPAA, GDPR | Compliance / Legal | ☐ Complete ☐ Pending |
| Trust account annual audit (legal industry) | Financial | Legal / State Bar | Finance / External Accountant | ☐ Complete ☐ Pending |

### June

| Activity | Category | Applicable Frameworks | Owner | Status |
|----------|----------|----------------------|-------|--------|
| Q2 quarterly access review | Access Control | SOC 2, HIPAA, GLBA | IT Security / IAM | ☐ Complete ☐ Pending |
| Q2 incident metrics review | Monitoring | All | CISO / SOC Manager | ☐ Complete ☐ Pending |
| Semi-annual RBAC role matrix review | Access Control | SOC 2, HIPAA | IAM / System Owners | ☐ Complete ☐ Pending |
| Annual vendor risk reassessment — High tier vendors | Vendor Management | All | Compliance / Procurement | ☐ Complete ☐ Pending |
| Mid-year compliance program status report to executive leadership | Governance | All | Compliance Officer | ☐ Complete ☐ Pending |
| Penetration test remediation follow-up | Security Testing | SOC 2, GLBA | IT Security | ☐ Complete ☐ Pending |

### July

| Activity | Category | Applicable Frameworks | Owner | Status |
|----------|----------|----------------------|-------|--------|
| Q2 compliance KPI review and reporting | Monitoring | All | Compliance Officer | ☐ Complete ☐ Pending |
| Semi-annual policy and SOP review cycle (begin) | Governance | All | All Document Owners | ☐ Complete ☐ Pending |
| Annual BC/DR plan review and update | Business Continuity | SOC 2, HIPAA | IT / BC Coordinator | ☐ Complete ☐ Pending |
| Semi-annual legal hold review (legal industry) | Records | Legal | General Counsel | ☐ Complete ☐ Pending |
| Conflict database integrity audit (legal industry) | Ethics | Legal | Conflicts Counsel | ☐ Complete ☐ Pending |

### August

| Activity | Category | Applicable Frameworks | Owner | Status |
|----------|----------|----------------------|-------|--------|
| Annual BC/DR test execution | Business Continuity | SOC 2, HIPAA | IT / BC Coordinator | ☐ Complete ☐ Pending |
| Semi-annual onboarding/offboarding process audit (sample review) | HR Compliance | All | IT Security / Compliance | ☐ Complete ☐ Pending |
| Annual review of data classification policy | Data Protection | All | CISO / Compliance | ☐ Complete ☐ Pending |
| Vendor risk reassessment — Medium tier vendors (biennial; if due) | Vendor Management | All | Compliance / Procurement | ☐ Complete ☐ Pending |
| Semi-annual physical security walkthrough | Physical Security | SOC 2, HIPAA | Facilities | ☐ Complete ☐ Pending |

### September

| Activity | Category | Applicable Frameworks | Owner | Status |
|----------|----------|----------------------|-------|--------|
| Q3 quarterly access review | Access Control | SOC 2, HIPAA, GLBA | IT Security / IAM | ☐ Complete ☐ Pending |
| Q3 incident metrics review | Monitoring | All | CISO / SOC Manager | ☐ Complete ☐ Pending |
| Semi-annual policy and SOP review cycle (complete) | Governance | All | All Document Owners | ☐ Complete ☐ Pending |
| SOC 2 readiness assessment (if audit period ends in Q4) | Audit Prep | SOC 2 | Compliance | ☐ Complete ☐ Pending |
| Annual Information Security Policy review and board approval | Governance | All | CISO / Board | ☐ Complete ☐ Pending |

### October

| Activity | Category | Applicable Frameworks | Owner | Status |
|----------|----------|----------------------|-------|--------|
| Q3 compliance KPI review and reporting | Monitoring | All | Compliance Officer | ☐ Complete ☐ Pending |
| Semi-annual breach response tabletop exercise | Incident Response | HIPAA, SOC 2 | Breach Coordinator / CISO | ☐ Complete ☐ Pending |
| Annual HIPAA risk assessment (if not combined with org-wide assessment) | Risk Management | HIPAA | HIPAA Security Officer | ☐ Complete ☐ Pending |
| Semi-annual vulnerability assessment (if not continuous) | Security Testing | SOC 2, GLBA | IT Security | ☐ Complete ☐ Pending |
| Annual review of Notice of Privacy Practices (HIPAA) | Privacy | HIPAA | Privacy Officer | ☐ Complete ☐ Pending |

### November

| Activity | Category | Applicable Frameworks | Owner | Status |
|----------|----------|----------------------|-------|--------|
| Annual GLBA program evaluation and board report | Governance | GLBA | CISO / Compliance | ☐ Complete ☐ Pending |
| Annual review of employee sanctions log | HR Compliance | HIPAA, All | Privacy Officer / HR | ☐ Complete ☐ Pending |
| Pre-year-end audit evidence collection and organization | Audit Prep | SOC 2, HIPAA | Audit Coordinator | ☐ Complete ☐ Pending |
| Annual review and renewal of destruction vendor contracts | Records | All | Procurement / Compliance | ☐ Complete ☐ Pending |
| Annual CLE compliance verification (legal industry) | Ethics | Legal | Compliance / HR | ☐ Complete ☐ Pending |

### December

| Activity | Category | Applicable Frameworks | Owner | Status |
|----------|----------|----------------------|-------|--------|
| Q4 quarterly access review | Access Control | SOC 2, HIPAA, GLBA | IT Security / IAM | ☐ Complete ☐ Pending |
| Q4 incident metrics review | Monitoring | All | CISO / SOC Manager | ☐ Complete ☐ Pending |
| Annual compliance program report to executive leadership / board | Governance | All | Compliance Officer | ☐ Complete ☐ Pending |
| Records disposition review (quarterly, end of year batch) | Records | All | Records Coordinator | ☐ Complete ☐ Pending |
| Plan and prepare Compliance Calendar for the next year | Governance | All | Compliance Officer | ☐ Complete ☐ Pending |
| Annual asset inventory verification | Asset Management | SOC 2, HIPAA | IT Operations | ☐ Complete ☐ Pending |
| Year-end vendor registry audit | Vendor Management | All | Procurement / Compliance | ☐ Complete ☐ Pending |

---

## Recurring Activities Summary (Quick Reference)

### Monthly

| Activity | Owner |
|----------|-------|
| Privileged access review | CISO / IT Security |
| Trust account reconciliation (legal) | Finance |
| Incident metrics tracking | SOC Manager |
| CCTV system functionality check | Facilities |
| Generator test | Facilities |

### Quarterly

| Activity | Owner |
|----------|-------|
| User access reviews and certifications | IT Security / Department Managers |
| Incident metrics review and reporting | CISO / SOC Manager |
| Compliance KPI dashboard update | Compliance Officer |
| Escalation path and contact list verification | SOC Manager |
| Records disposition review | Records Coordinator |
| Vendor SLA performance review (Critical/High) | Business Owners |
| Risk register review | CISO / Compliance |
| CCTV coverage assessment | Physical Security Manager |

### Semi-Annually

| Activity | Owner |
|----------|-------|
| Breach response tabletop exercise | Breach Coordinator / CISO |
| Policy and SOP review cycle | All Document Owners |
| Physical security walkthrough | Physical Security Manager |
| RBAC role matrix review | IAM / System Owners |
| Vulnerability assessment (if not continuous) | IT Security |
| Onboarding/offboarding process audit | IT Security / Compliance |
| Environmental controls inspection | Facilities |
| Ethical wall compliance verification (legal) | Conflicts Counsel |

### Annually

| Activity | Owner |
|----------|-------|
| Organizational risk assessment | CISO / Compliance |
| Penetration test | IT Security (external) |
| Security awareness training | HR / IT Security |
| Policy review and board approval | CISO / Board |
| BC/DR plan review and test | IT / BC Coordinator |
| Vendor reassessments (Critical/High) | Compliance / Procurement |
| Compliance program report to leadership | Compliance Officer |
| HIPAA breach log submission to HHS | Privacy Officer |
| Asset inventory verification | IT Operations |
| Cyber insurance review | Legal / Risk |
| Destruction vendor contract review | Procurement |

---

## Calendar Maintenance

| Activity | Frequency | Owner |
|----------|-----------|-------|
| Update completion status | As activities are completed | Responsible Owners |
| Review calendar for accuracy and completeness | Monthly | Compliance Officer |
| Plan and prepare next year's calendar | December (annually) | Compliance Officer |
| Adjust for regulatory changes | As needed | Compliance / Legal |

---

## Regulatory Filing Deadlines (Critical Dates)

| Filing / Deadline | Due Date | Framework | Owner | Notes |
|------------------|---------|-----------|-------|-------|
| HIPAA breach log (breaches <500) to HHS | Within 60 days of calendar year end (~ March 1) | HIPAA | Privacy Officer | Annual submission for prior year |
| HIPAA breach notification (≥500 individuals) | Within 60 days of discovery | HIPAA | Privacy Officer | Per-incident; not calendar-based |
| SOC 2 audit period end | Per engagement | SOC 2 | Compliance | Typically calendar or fiscal year end |
| State breach notifications | Varies by state (typically 30–60 days) | State laws | Legal / Compliance | Per-incident |
| Annual board security report | Per board calendar | GLBA, SOC 2 | CISO | Usually Q4 or Q1 |
| CLE compliance deadline | Varies by state bar | Legal | Individual attorneys | Per state bar rules |
| IOLTA compliance certification | Per state bar schedule | Legal | Managing Partner | Annual |

---

*This calendar is part of the Compliance-Ready SOP Toolkit. Customize based on your regulatory requirements and organizational review cycles. Consult legal/compliance professionals for jurisdiction-specific deadlines.*
