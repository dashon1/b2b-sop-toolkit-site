# SOP-08: Audit Preparation and Execution

**Document ID:** SOP-08-APE  
**Version:** 1.0  
**Effective Date:** _______________  
**Last Reviewed:** _______________  
**Document Owner:** Compliance Officer  
**Classification:** Confidential — Internal Use Only

---

## 1. Purpose

This Standard Operating Procedure provides a structured, repeatable process for preparing for, supporting, and following up on internal and external compliance audits. Proper audit preparation reduces findings, demonstrates due diligence, and ensures the organization can demonstrate compliance with applicable regulatory frameworks (HIPAA, SOC 2, SOX, PCI DSS, state regulations) to auditors, regulators, and stakeholders.

## 2. Scope

This SOP applies to:

- All internal compliance audits, self-assessments, and mock audits
- All external audits: SOC 2 Type I/II, HIPAA compliance audits, regulatory examinations, state and federal inspections, client audits, and financial audits
- All departments and business functions subject to regulatory or contractual compliance requirements
- All personnel who participate in audit activities as auditees, evidence providers, or subject matter experts

## 3. Definitions

| Term | Definition |
|------|-----------|
| **Audit** | A systematic, independent examination of an organization's processes, controls, and records to assess compliance with defined standards |
| **Internal Audit** | An audit conducted by the organization's own compliance or audit team |
| **External Audit** | An audit conducted by an independent third party (auditor, regulator, or client) |
| **Audit Evidence** | Information used by an auditor to determine whether controls are designed and operating effectively (documents, system screenshots, logs, interview notes) |
| **Control** | A policy, procedure, practice, or organizational structure designed to manage risk and provide reasonable assurance that objectives will be achieved |
| **Finding** | An auditor's determination that a control is deficient, not implemented, or not operating effectively |
| **CAP (Corrective Action Plan)** | A documented plan to remediate an audit finding, including actions, owners, and deadlines |

## 4. Responsibilities

| Role | Responsibilities |
|------|-----------------|
| **Compliance Officer** | Owns this SOP; coordinates audit preparation; serves as primary audit liaison; tracks findings and CAPs |
| **Audit Coordinator** | Manages day-to-day audit logistics; schedules interviews; collects and organizes evidence; maintains the audit evidence repository |
| **Department Managers / Control Owners** | Ensure their areas are audit-ready; provide evidence and subject matter expertise; implement corrective actions |
| **IT Security** | Provides technical evidence (system configurations, access logs, vulnerability scans, penetration test results) |
| **Legal Counsel** | Reviews audit scope and engagement letters; advises on privilege and disclosure; reviews draft audit reports |
| **Executive Sponsor** | Provides organizational authority for audit activities; receives briefings on audit status and findings |
| **All Personnel** | Cooperate with auditors; provide truthful and complete responses; follow the communication protocols in this SOP |

## 5. Procedures

### 5.1 Phase 1 — Audit Planning and Readiness (12–16 Weeks Before Audit)

| Step | Action | Responsible Party | Documentation |
|------|--------|------------------|---------------|
| 1.1 | Identify the upcoming audit: type (SOC 2, HIPAA, regulatory, client), scope, framework, and audit period | Compliance Officer | Audit calendar entry |
| 1.2 | Review the audit engagement letter or regulatory notice; confirm scope, timeline, access requirements, and auditor expectations | Compliance Officer / Legal | Reviewed engagement letter |
| 1.3 | Identify the Audit Coordinator and assemble the Audit Readiness Team (representatives from each in-scope department) | Compliance Officer | Audit Readiness Team roster |
| 1.4 | Conduct a kick-off meeting with the Audit Readiness Team to review: audit scope, timeline, evidence requirements, roles, and communication protocols | Compliance Officer | Meeting minutes; distributed schedule |
| 1.5 | Map audit requirements to organizational controls: identify which SOPs, policies, processes, and systems are in scope | Audit Coordinator | Control-to-Requirement Mapping Matrix |
| 1.6 | Identify evidence artifacts required for each control and assign evidence collection owners | Audit Coordinator | Evidence Request List with owners |

### 5.2 Phase 2 — Self-Assessment and Gap Remediation (8–12 Weeks Before Audit)

| Step | Action | Responsible Party | Documentation |
|------|--------|------------------|---------------|
| 2.1 | Conduct an internal self-assessment / mock audit against the audit framework | Compliance Officer / Internal Audit | Self-Assessment Report |
| 2.2 | For each control, verify: (a) the control is documented in an approved policy or SOP; (b) evidence of control operation exists for the audit period; (c) the control is operating as designed | Control Owners | Control testing worksheets |
| 2.3 | Identify gaps: missing documentation, insufficient evidence, control deficiencies, or inconsistent implementation | Audit Coordinator | Gap Analysis Report |
| 2.4 | For each identified gap, create a remediation task with owner, action items, and deadline (must be resolved before audit start) | Compliance Officer | Remediation Task Tracker |
| 2.5 | Prioritize remediation: Critical gaps (control not implemented) → High (evidence missing) → Medium (documentation incomplete) → Low (formatting/consistency) | Compliance Officer | Prioritized remediation plan |
| 2.6 | Track remediation progress weekly until all items are resolved | Audit Coordinator | Weekly status reports |
| 2.7 | Conduct a follow-up assessment to verify all gaps have been remediated | Compliance Officer | Remediation verification |

### 5.3 Phase 3 — Evidence Collection and Organization (4–8 Weeks Before Audit)

| Step | Action | Responsible Party | Documentation |
|------|--------|------------------|---------------|
| 3.1 | Create a centralized, organized audit evidence repository (shared drive, GRC platform, or secure file share) with restricted access | Audit Coordinator | Evidence repository setup |
| 3.2 | Organize the repository by audit framework section or control area | Audit Coordinator | Repository structure |
| 3.3 | Collect evidence artifacts per the Evidence Request List; examples include: approved policies and SOPs with version history; access control reports and review certifications; training completion records; incident logs and response documentation; vulnerability scan results and remediation records; change management tickets; vendor risk assessments and BAAs; system configuration documentation; meeting minutes demonstrating governance | Control Owners / Audit Coordinator | Collected evidence artifacts |
| 3.4 | Review each evidence artifact for: completeness (covers the full audit period); accuracy (matches the control description); currency (reflects current state, not outdated versions); sensitivity (redact information not in scope) | Audit Coordinator | Evidence review checklist |
| 3.5 | Create an Evidence Index mapping each audit requirement to the specific evidence artifact(s) provided | Audit Coordinator | Evidence Index |
| 3.6 | Conduct a final evidence completeness review with Control Owners | Audit Coordinator | Completeness sign-off |

### 5.4 Phase 4 — Audit Execution Support (During Audit)

| Step | Action | Responsible Party | Documentation |
|------|--------|------------------|---------------|
| 4.1 | Provide auditors with access to the evidence repository and any required systems (read-only access to production systems if needed) | Audit Coordinator / IT | Access provisioning log |
| 4.2 | Designate a single point of contact (Audit Coordinator) for all auditor requests; all evidence and information must flow through this person | Compliance Officer | Communication protocol |
| 4.3 | Schedule and coordinate auditor interviews with subject matter experts | Audit Coordinator | Interview schedule |
| 4.4 | Brief interviewees before their sessions: review the scope of questions, remind them to answer only what is asked, be truthful, and refer questions outside their knowledge to the Audit Coordinator | Audit Coordinator | Pre-interview briefing log |
| 4.5 | Track all auditor requests for information (RFIs) and ensure timely responses (within 24 hours or as agreed) | Audit Coordinator | RFI tracking log |
| 4.6 | Log all evidence provided to auditors, including date, description, and delivery method | Audit Coordinator | Evidence delivery log |
| 4.7 | Conduct daily internal status meetings during the audit to address emerging issues, additional evidence requests, or potential findings | Audit Coordinator | Daily status meeting notes |
| 4.8 | If auditors identify potential findings during fieldwork, immediately engage the Control Owner and Compliance Officer to understand the issue and begin preparing a response | Compliance Officer | Potential finding notes |

### 5.5 Phase 5 — Audit Close-Out and Finding Management (Post-Audit)

| Step | Action | Responsible Party | Documentation |
|------|--------|------------------|---------------|
| 5.1 | Attend the audit exit meeting / closing conference to receive preliminary findings and observations | Compliance Officer / Executive Sponsor | Exit meeting notes |
| 5.2 | Review the draft audit report for factual accuracy; submit corrections or management responses within the specified timeline | Compliance Officer / Control Owners | Management response to draft |
| 5.3 | For each finding, develop a Corrective Action Plan (CAP) including: root cause analysis; specific remediation actions; responsible owner; implementation deadline; evidence of remediation | Control Owner / Compliance Officer | Corrective Action Plans |
| 5.4 | Obtain executive sign-off on all CAPs | Executive Sponsor | Signed CAPs |
| 5.5 | Submit management responses and CAPs to the auditor | Compliance Officer | Submitted responses |
| 5.6 | Track CAP implementation to completion; collect evidence of remediation | Audit Coordinator | CAP tracking dashboard |
| 5.7 | Conduct a post-audit lessons-learned session with the Audit Readiness Team | Compliance Officer | Lessons learned report |
| 5.8 | Update SOPs, policies, controls, and training based on findings and lessons learned | Control Owners | Updated documents |
| 5.9 | Archive the complete audit file: engagement letter, evidence index, RFI logs, evidence delivery logs, draft and final reports, CAPs, and remediation evidence | Audit Coordinator | Archived audit file |

## 6. Audit-Ready Evidence Checklist

The following evidence categories should be maintained continuously (not assembled only before an audit):

| Evidence Category | Examples | Responsible Party |
|------------------|---------|------------------|
| **Governance** | Approved policies, SOPs, organizational charts, committee charters, board/committee meeting minutes | Compliance Officer |
| **Risk Management** | Risk assessments, risk register, risk treatment plans | Compliance / CISO |
| **Access Control** | User access reports, quarterly access reviews, privileged access reviews, onboarding/offboarding records | IT Security / IAM |
| **Change Management** | Change tickets, approval records, testing documentation, rollback plans | IT Operations |
| **Incident Management** | Incident tickets, investigation reports, post-incident reviews, notification records | CISO / SOC |
| **Vulnerability Management** | Vulnerability scan reports, remediation tracking, penetration test results | IT Security |
| **Training** | Training completion records, training content, annual acknowledgments | HR / Compliance |
| **Vendor Management** | Vendor assessments, contracts, BAAs, monitoring records | Compliance / Procurement |
| **Business Continuity** | BC/DR plans, test results, recovery documentation | IT / Business Continuity |
| **Physical Security** | Access logs, visitor logs, CCTV records, environmental monitoring | Facilities |

## 7. Documentation Requirements

- [ ] Audit Calendar (annual)
- [ ] Audit Readiness Team Roster
- [ ] Control-to-Requirement Mapping Matrix
- [ ] Evidence Request List
- [ ] Self-Assessment / Mock Audit Report
- [ ] Gap Analysis Report
- [ ] Remediation Task Tracker
- [ ] Evidence Repository with Evidence Index
- [ ] RFI Tracking Log
- [ ] Evidence Delivery Log
- [ ] Exit Meeting Notes
- [ ] Corrective Action Plans
- [ ] Post-Audit Lessons Learned Report
- [ ] Archived Audit File (complete)

**Retention Period:** All audit-related documentation must be retained for a minimum of **7 years** from the audit date.

## 8. Key Performance Indicators

| Metric | Target |
|--------|--------|
| Self-assessment completion before external audit | 100% (completed 8+ weeks prior) |
| Gap remediation before audit start | 100% of Critical and High items |
| Evidence requests fulfilled within 24 hours during audit | > 95% |
| CAP completion within assigned deadlines | 100% |
| Repeat findings (same finding in consecutive audits) | 0 |

## 9. Related Documents

- All SOPs in this toolkit (SOP-01 through SOP-07)
- Information Security Policy
- Risk Management Policy
- Compliance Program Charter
- All industry-specific modules

## 10. Review Schedule

| Review Activity | Frequency | Responsible Party |
|----------------|-----------|------------------|
| Full SOP review and update | Annually | Compliance Officer |
| Audit calendar review and update | Quarterly | Compliance Officer |
| Evidence repository structure review | Semi-annually | Audit Coordinator |
| Mock audit / self-assessment | Annually (minimum) or before major external audits | Compliance Officer |
| Post-audit review | After every external audit | Compliance Officer |

## 11. Revision History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | _____________ | _____________ | Initial release |

## 12. Approval

| Role | Name | Signature | Date |
|------|------|-----------|------|
| Compliance Officer | | | |
| CISO | | | |
| CFO | | | |
| CEO / Executive Sponsor | | | |
