# Industry Module: SOC 2 / Financial Services Compliance

**Document ID:** MOD-SOC2-FIN  
**Version:** 1.0  
**Effective Date:** _______________  
**Last Reviewed:** _______________  
**Document Owner:** Compliance Officer / CISO  
**Classification:** Confidential — Internal Use Only

---

## 1. Purpose

This module supplements the core SOP toolkit with finance and technology industry-specific protocols required for SOC 2 compliance (AICPA Trust Services Criteria), Gramm-Leach-Bliley Act (GLBA) requirements, and related financial services regulatory obligations. It provides actionable controls mapped to the five SOC 2 Trust Services Categories and financial industry best practices.

## 2. Applicability

This module applies to organizations that:

- Are pursuing or maintaining a SOC 2 Type I or Type II attestation
- Provide SaaS, cloud, managed IT, or technology services to financial institutions or enterprises
- Are financial institutions subject to GLBA and related regulations
- Handle Nonpublic Personal Information (NPI) of financial services customers
- Are subject to SEC, FINRA, OCC, FDIC, or state financial regulatory oversight

## 3. Regulatory and Framework Reference

| Framework/Regulation | Key Requirements | Oversight |
|---------------------|-----------------|-----------|
| **SOC 2 (AICPA TSC)** | Trust Services Criteria across 5 categories: Security, Availability, Processing Integrity, Confidentiality, Privacy | CPA audit firms (AICPA standards) |
| **GLBA** | Safeguards Rule: protect NPI; Privacy Rule: notice of information sharing; Pretexting provisions | FTC, OCC, FDIC, Federal Reserve |
| **SOX (Sarbanes-Oxley)** | Internal controls over financial reporting (ICFR); applies to public companies | SEC / PCAOB |
| **PCI DSS** | Payment card data protection (if processing, storing, or transmitting cardholder data) | PCI SSC / Card brands |
| **NYDFS Cybersecurity (23 NYCRR 500)** | Cybersecurity program requirements for financial services companies operating in New York | NYDFS |
| **SEC Regulation S-P** | Privacy of consumer financial information | SEC |

## 4. SOC 2 Trust Services Criteria — Control Mapping

### 4.1 CC1 — Control Environment (COSO Principle 1–5)

| Criteria | Required Controls | Evidence | Core SOP Reference |
|----------|------------------|----------|-------------------|
| CC1.1 — Commitment to integrity and ethics | Code of Conduct policy; annual acknowledgment; ethics hotline; sanctions policy | Signed acknowledgments; hotline records | SOP-03 (Onboarding) |
| CC1.2 — Board/management oversight | Governance structure; security committee charter; regular security reporting to leadership | Committee meeting minutes; security reports | SOP-08 (Audit Prep) |
| CC1.3 — Authority and responsibility | Organizational chart; defined roles (CISO, DPO, Compliance); job descriptions with security responsibilities | Org chart; role definitions; RACI matrices | All SOPs (Section 4) |
| CC1.4 — Competence commitment | Background checks; role-based training; competency assessments; professional development | Background check records; training logs | SOP-03 |
| CC1.5 — Accountability | Performance evaluations include security metrics; sanctions for policy violations | Evaluation records; sanctions log | SOP-03, SOP-04 |

### 4.2 CC2 — Communication and Information

| Criteria | Required Controls | Evidence |
|----------|------------------|----------|
| CC2.1 — Quality information for internal control | Information classification policy; data quality controls; system logs for decision-making | Classification policy; data quality reports |
| CC2.2 — Internal communication | Security awareness program; policy distribution; incident communication protocols | Training records; policy acknowledgments; communication logs |
| CC2.3 — External communication | Customer notifications; regulatory reporting; vendor communications; public security disclosures | Notification records; regulatory filings; vendor correspondence |

### 4.3 CC3 — Risk Assessment

| Criteria | Required Controls | Evidence |
|----------|------------------|----------|
| CC3.1 — Risk identification | Annual risk assessment; threat modeling; asset inventory; vulnerability identification | Risk assessment report; asset inventory |
| CC3.2 — Fraud risk assessment | Fraud risk evaluation; segregation of duties analysis; whistleblower program | Fraud risk assessment; SoD matrix; hotline records |
| CC3.3 — Change-related risk | Change management risk assessment; impact analysis for significant changes | Change management records; impact assessments |
| CC3.4 — Risk assessment updates | Quarterly risk register review; event-triggered reassessments; emerging threat monitoring | Updated risk register; quarterly review records |

### 4.4 CC4 — Monitoring Activities

| Criteria | Required Controls | Evidence |
|----------|------------------|----------|
| CC4.1 — Ongoing and separate evaluations | Continuous monitoring (SIEM, IDS/IPS); internal audits; management reviews; control self-assessments | SIEM dashboards; audit reports; self-assessment results |
| CC4.2 — Deficiency communication | Finding tracking; corrective action plans; escalation to management; board reporting | Finding logs; CAP tracking; management reports |

### 4.5 CC5 — Control Activities

| Criteria | Required Controls | Evidence |
|----------|------------------|----------|
| CC5.1 — Control selection and development | Controls mapped to risks; control design documentation; policies and procedures | Control matrix; policy library |
| CC5.2 — Technology general controls | Logical access controls; change management; IT operations; system development lifecycle | Access reports; change tickets; operations logs |
| CC5.3 — Policy deployment | Policy management lifecycle; version control; distribution; acknowledgment; exception management | Policy library; acknowledgment records; exception log |

### 4.6 CC6 — Logical and Physical Access Controls

| Criteria | Required Controls | Evidence | Core SOP Reference |
|----------|------------------|----------|-------------------|
| CC6.1 — Logical access security | Authentication, authorization, and accountability mechanisms; SSO; MFA; session management | System configurations; access logs | SOP-02 |
| CC6.2 — Access provisioning | Role-based access; approval workflows; least privilege; segregation of duties | Access requests; RBAC matrix; SoD analysis | SOP-02, SOP-03 |
| CC6.3 — Access removal | Timely deprovisioning; offboarding procedures; automated account disablement | Deprovisioning records; offboarding logs | SOP-02, SOP-03 |
| CC6.4 — Physical access restrictions | Badge access; visitor management; CCTV; environmental controls | Access logs; visitor logs; CCTV records | SOP-07 |
| CC6.5 — Asset disposal | Secure media destruction; data sanitization; disposal verification | Destruction certificates; sanitization records | SOP-05 |
| CC6.6 — Threat protection | Endpoint protection; network security; vulnerability management; intrusion detection | AV reports; firewall rules; vuln scan results | SOP-01, SOP-04 |
| CC6.7 — Transmission security | Encryption in transit (TLS 1.2+); secure file transfer; email encryption | TLS configurations; encryption policies | SOP-02 |
| CC6.8 — Unauthorized changes | File integrity monitoring; configuration management; change detection alerts | FIM logs; configuration baselines | SOP-04 |

### 4.7 CC7 — System Operations

| Criteria | Required Controls | Evidence | Core SOP Reference |
|----------|------------------|----------|-------------------|
| CC7.1 — Anomaly detection | SIEM monitoring; anomaly detection rules; behavioral analytics; alert thresholds | SIEM configuration; alert rules | SOP-04 |
| CC7.2 — Incident monitoring | 24/7 monitoring coverage; event correlation; escalation procedures | SOC operations records; shift logs | SOP-04 |
| CC7.3 — Security incident evaluation | Incident classification; severity assessment; impact analysis | Incident tickets; severity matrix | SOP-04 |
| CC7.4 — Incident response | Response procedures; containment; eradication; recovery; notification | Incident response records | SOP-01, SOP-04 |
| CC7.5 — Incident recovery | Recovery procedures; backup restoration; post-incident verification | Recovery logs; restoration records | SOP-01 |

### 4.8 CC8 — Change Management

| Criteria | Required Controls | Evidence |
|----------|------------------|----------|
| CC8.1 — Change authorization and testing | Formal change request process; risk and impact assessment; testing in non-production; rollback planning; segregation of development and production; authorized approvals before deployment | Change tickets with approvals; test results; deployment records |

### 4.9 CC9 — Risk Mitigation

| Criteria | Required Controls | Evidence | Core SOP Reference |
|----------|------------------|----------|-------------------|
| CC9.1 — Risk identification and assessment | Identified risks are assessed and mitigated; residual risk is accepted by management | Risk register; risk treatment plans | SOP-08 |
| CC9.2 — Vendor risk management | Third-party risk assessment; vendor monitoring; contractual protections | Vendor assessments; contracts; monitoring records | SOP-06 |

## 5. SOC 2 Availability Criteria (if in scope)

| Criteria | Required Controls | Evidence |
|----------|------------------|----------|
| A1.1 — Capacity management | Capacity planning; performance monitoring; scaling procedures | Capacity reports; monitoring dashboards |
| A1.2 — Environmental protections | Data center environmental controls; redundant power; cooling; fire suppression | Environmental monitoring records | 
| A1.3 — Recovery operations | Backup procedures; disaster recovery plan; tested recovery procedures; RTO/RPO definitions | DR plan; test results; backup verification logs |

## 6. GLBA-Specific Requirements

### 6.1 GLBA Safeguards Rule Compliance

| Requirement | Implementation |
|-------------|---------------|
| **Designate a Qualified Individual** | Appoint a CISO or equivalent to oversee the information security program |
| **Risk Assessment** | Conduct a written risk assessment identifying threats to NPI; assess safeguard effectiveness |
| **Safeguard Implementation** | Implement access controls, encryption, MFA, secure development, change management, and data retention/disposal |
| **Service Provider Oversight** | Select service providers with adequate safeguards; contractually require NPI protection; monitor compliance |
| **Program Evaluation and Adjustment** | Continuously evaluate and adjust the security program; annual reporting to the board of directors |
| **Incident Response Plan** | Maintain a written incident response plan addressing data breaches involving NPI |
| **Annual Penetration Testing** | Conduct annual penetration testing and semi-annual vulnerability assessments |

### 6.2 GLBA Privacy Rule

| Requirement | Action |
|-------------|--------|
| Initial privacy notice | Provide customers with a clear notice of information-sharing practices at account opening |
| Annual privacy notice | Provide annual privacy notice (if sharing NPI with non-affiliated third parties or if practices change) |
| Opt-out rights | Provide customers the right to opt out of information sharing with non-affiliated third parties |
| Exceptions | Opt-out not required for sharing with service providers under contract, joint marketing agreements, or as required by law |

## 7. SOC 2 Audit-Specific Preparation

### 7.1 SOC 2 Type I vs. Type II

| Attribute | Type I | Type II |
|-----------|--------|---------|
| **Scope** | Description of system and suitability of control design | Description of system, suitability of control design, AND operating effectiveness |
| **Period** | Point-in-time (as of a specific date) | Over a period (typically 6–12 months) |
| **Evidence** | Control documentation; system descriptions | Control documentation + evidence of consistent operation over the period |
| **Value** | Useful for first-time SOC 2 or new controls | Preferred by customers and regulators; demonstrates sustained compliance |

### 7.2 Common SOC 2 Audit Evidence by Category

| Category | Evidence Types |
|----------|--------------|
| **Policies and Procedures** | Information Security Policy, Access Control Policy, Change Management Policy, Incident Response Plan, BC/DR Plan, all SOPs in this toolkit |
| **Access Management** | User access reports; quarterly access reviews with certifications; privileged access reviews; onboarding/offboarding records; MFA enrollment reports |
| **Change Management** | Change tickets with approvals, testing, and deployment records; emergency change documentation; rollback documentation |
| **Incident Management** | Incident tickets; severity classifications; response timelines; post-incident reviews; notification records |
| **Monitoring** | SIEM configuration and alert rules; vulnerability scan results; penetration test reports; monitoring dashboards |
| **Vendor Management** | Vendor risk assessments; contracts with security provisions; annual reassessments; SOC 2 reports from critical vendors |
| **Training** | Security awareness training records; completion certificates; annual acknowledgments |
| **Governance** | Risk assessments; risk register; committee meeting minutes; board reporting; management review records |

## 8. Financial Data Handling Protocols

| Control Area | Standard |
|-------------|----------|
| **Encryption at rest** | AES-256 for all NPI and financial data at rest |
| **Encryption in transit** | TLS 1.2+ for all data in transit; SFTP for file transfers; no unencrypted financial data transmission |
| **Database security** | Encrypted connections; parameterized queries; audit logging; row-level security where applicable |
| **Key management** | Hardware security modules (HSM) or approved KMS; key rotation at least annually; separation of duties for key management |
| **Data masking** | Production NPI masked in non-production environments; PAN masking per PCI DSS |
| **Segregation of duties** | Financial transaction authorization ≠ execution ≠ recording; access to financial systems requires dual approval |
| **Audit logging** | All access to financial systems logged with user ID, timestamp, action, and result; logs protected from tampering; retained per policy |

## 9. Documentation Requirements (SOC 2 / Financial-Specific)

- [ ] Information Security Policy (board-approved, current)
- [ ] Risk Assessment (annual, written)
- [ ] Risk Register (current, with risk owners and treatment plans)
- [ ] System Description (for SOC 2 report)
- [ ] Control Matrix (mapped to Trust Services Criteria)
- [ ] All evidence categories listed in Section 7.2
- [ ] GLBA privacy notices (initial and annual)
- [ ] Penetration test results (annual)
- [ ] Vulnerability assessment results (semi-annual minimum)
- [ ] Board/management security reporting (annual minimum)
- [ ] Vendor SOC 2 reports (for critical vendors)
- [ ] Business Continuity / Disaster Recovery test results

**Retention Period:** SOC 2 and financial compliance records must be retained for **7 years** or as required by applicable financial regulation.

## 10. Compliance Monitoring Schedule

| Activity | Frequency | Responsible Party |
|----------|-----------|------------------|
| SOC 2 internal control testing | Quarterly | Internal Audit / Compliance |
| Risk assessment and register update | Annually (quarterly review) | CISO / Compliance |
| Penetration test | Annually | IT Security (external firm) |
| Vulnerability scanning | Continuously or semi-annually minimum | IT Security |
| Access reviews | Quarterly | IAM / Managers |
| Vendor reassessments (critical) | Annually | Compliance / Procurement |
| Board security reporting | Annually minimum | CISO |
| GLBA program evaluation | Annually | CISO / Compliance |
| SOC 2 readiness assessment | 3 months before audit period | Compliance |

## 11. Related Core SOPs

| Core SOP | SOC 2/Financial Supplement |
|----------|---------------------------|
| SOP-01: Data Breach Response | CC7.3–CC7.5 incident management; GLBA incident response requirements |
| SOP-02: Access Control | CC6.1–CC6.3 logical access; GLBA safeguards |
| SOP-04: Incident Reporting | CC7.1–CC7.2 monitoring and detection |
| SOP-05: Record Retention | Financial regulatory retention requirements (7 years) |
| SOP-06: Vendor Assessment | CC9.2 vendor risk management; GLBA service provider oversight |
| SOP-08: Audit Preparation | Section 7 — SOC 2-specific audit preparation |

## 12. Revision History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | _____________ | _____________ | Initial release |

## 13. Approval

| Role | Name | Signature | Date |
|------|------|-----------|------|
| CISO | | | |
| Compliance Officer | | | |
| CFO | | | |
| General Counsel | | | |
