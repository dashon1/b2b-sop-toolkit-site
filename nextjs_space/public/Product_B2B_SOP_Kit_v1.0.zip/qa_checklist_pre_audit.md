# QA Checklist: Pre-Audit Readiness

**Document ID:** QA-PA-001  
**Version:** 1.0  
**Effective Date:** _______________  
**Classification:** Confidential — Internal Use Only

---

## Purpose

This 15-point checklist ensures the organization is fully prepared for an upcoming external or internal audit. Complete this checklist 4–6 weeks before the audit start date. It verifies that documentation is current, evidence is assembled, personnel are briefed, and logistics are arranged. This checklist supplements SOP-08 (Audit Preparation and Execution).

---

## Instructions

- Begin this checklist at least **6 weeks** before the scheduled audit
- Mark each item: **✅ Complete** | **❌ Not Complete** | **⚠️ In Progress** | **N/A Not Applicable**
- All **Not Complete** items at the 2-week mark must be escalated to the Compliance Officer
- Target: **100% Complete** by 1 week before audit start

---

## Audit Information

| Field | Value |
|-------|-------|
| **Audit Type** | ☐ SOC 2 Type I ☐ SOC 2 Type II ☐ HIPAA ☐ Regulatory Examination ☐ Client Audit ☐ Financial Audit ☐ Internal Audit ☐ Other: _________ |
| **Audit Framework / Standard** | |
| **Auditor / Firm** | |
| **Audit Period** | From: _______________ To: _______________ |
| **Audit Start Date** | |
| **Audit Coordinator** | |
| **Compliance Officer** | |
| **Date Checklist Initiated** | |

---

## Pre-Audit Readiness Checklist

### Governance and Documentation

| # | Verification Item | Status | Deadline | Owner | Notes |
|---|------------------|--------|----------|-------|-------|
| 1 | **Policies and SOPs Current:** All in-scope policies and SOPs have been reviewed, are within their review cycle, and reflect current practices. Version histories are accurate. Approval signatures are documented. No policies are expired or overdue for review. | ☐ Complete ☐ Not Complete ☐ In Progress ☐ N/A | 6 weeks prior | Compliance Officer | |
| 2 | **Control-to-Requirement Mapping:** A complete mapping matrix exists that maps each audit requirement (e.g., each SOC 2 TSC criterion or HIPAA standard) to the specific organizational control, policy/SOP, and evidence artifact that satisfies it. The matrix has been reviewed and validated. | ☐ Complete ☐ Not Complete ☐ In Progress ☐ N/A | 5 weeks prior | Audit Coordinator | |
| 3 | **Risk Assessment Current:** The annual risk assessment has been completed within the last 12 months. The risk register is up-to-date with current risk owners, treatment plans, and residual risk acceptance. Findings from the risk assessment have been addressed. | ☐ Complete ☐ Not Complete ☐ In Progress ☐ N/A | 6 weeks prior | CISO / Compliance | |

### Evidence Readiness

| # | Verification Item | Status | Deadline | Owner | Notes |
|---|------------------|--------|----------|-------|-------|
| 4 | **Evidence Repository Organized:** A centralized, structured evidence repository is set up and accessible to the Audit Coordinator. Evidence is organized by audit framework section or control area. File naming conventions are consistent. An Evidence Index maps each requirement to specific artifacts. | ☐ Complete ☐ Not Complete ☐ In Progress ☐ N/A | 4 weeks prior | Audit Coordinator | |
| 5 | **Evidence Collected and Validated:** Evidence artifacts for the full audit period have been collected, reviewed for completeness, and validated for accuracy. Key evidence includes: access review certifications, training records, incident logs, change management tickets, vulnerability scan reports, penetration test results, vendor assessments, and meeting minutes. Gaps have been identified and addressed. | ☐ Complete ☐ Not Complete ☐ In Progress ☐ N/A | 3 weeks prior | Control Owners / Audit Coordinator | |
| 6 | **Prior Audit Findings Resolved:** All corrective action plans from the previous audit have been completed and verified. Evidence of remediation is documented and available. If any prior findings remain open, a written status update and remediation plan is prepared for the auditor. | ☐ Complete ☐ Not Complete ☐ In Progress ☐ N/A | 4 weeks prior | Finding Owners / Compliance | |

### Technical and Operational Readiness

| # | Verification Item | Status | Deadline | Owner | Notes |
|---|------------------|--------|----------|-------|-------|
| 7 | **Access Reviews Completed:** Quarterly (or periodic) user access reviews for all in-scope systems have been completed for the audit period. Manager certifications are signed and filed. Identified excess access has been revoked and documented. Privileged access reviews are current. | ☐ Complete ☐ Not Complete ☐ In Progress ☐ N/A | 4 weeks prior | IT Security / IAM | |
| 8 | **Vulnerability and Penetration Testing Current:** Vulnerability scans have been conducted per schedule (continuous or semi-annual minimum). Annual penetration test has been completed. Reports are available. Critical and high findings have documented remediation with evidence. | ☐ Complete ☐ Not Complete ☐ In Progress ☐ N/A | 4 weeks prior | IT Security | |
| 9 | **Change Management Records Complete:** All changes to in-scope systems during the audit period are documented with: change request, risk assessment, approval, testing evidence, and deployment record. Emergency changes have post-implementation review documentation. Unauthorized changes are identified and addressed. | ☐ Complete ☐ Not Complete ☐ In Progress ☐ N/A | 3 weeks prior | IT Operations | |
| 10 | **Business Continuity / DR Testing Documented:** BC/DR plans are current and approved. A BC/DR test has been conducted within the last 12 months. Test results, including recovery times and identified gaps, are documented. Gaps have been addressed or have documented remediation plans. | ☐ Complete ☐ Not Complete ☐ In Progress ☐ N/A | 4 weeks prior | IT / BC Coordinator | |

### Personnel and Logistics

| # | Verification Item | Status | Deadline | Owner | Notes |
|---|------------------|--------|----------|-------|-------|
| 11 | **Training Records Complete:** Mandatory security awareness and compliance training has been completed by all in-scope personnel for the audit period. Completion certificates are available. Personnel who have not completed training are identified, and catch-up training is scheduled before the audit. | ☐ Complete ☐ Not Complete ☐ In Progress ☐ N/A | 4 weeks prior | HR / Compliance | |
| 12 | **Interview Subjects Identified and Briefed:** Personnel who will be interviewed by auditors have been identified (control owners, IT staff, management, HR, facilities). Pre-interview briefings have been scheduled. Briefing content includes: audit scope, expected topics, interview protocols (answer truthfully, only what is asked, refer unknown questions to Audit Coordinator). | ☐ Complete ☐ Not Complete ☐ In Progress ☐ N/A | 2 weeks prior | Audit Coordinator | |
| 13 | **Auditor Logistics Arranged:** Physical workspace or virtual meeting rooms are reserved for auditors. System access (read-only) has been provisioned or is ready to provision. Network/Wi-Fi access for on-site auditors is prepared. Key contact list with phone numbers has been shared with the audit team. NDA or access agreements are executed if required. | ☐ Complete ☐ Not Complete ☐ In Progress ☐ N/A | 2 weeks prior | Audit Coordinator / IT / Facilities | |

### Self-Assessment and Final Review

| # | Verification Item | Status | Deadline | Owner | Notes |
|---|------------------|--------|----------|-------|-------|
| 14 | **Internal Self-Assessment / Mock Audit Completed:** An internal readiness review or mock audit has been conducted against the audit framework. Results have been documented. Gaps identified during the self-assessment have been remediated. The self-assessment report is available for reference during the audit. | ☐ Complete ☐ Not Complete ☐ In Progress ☐ N/A | 4 weeks prior | Compliance Officer | |
| 15 | **Final Readiness Review Meeting Held:** A final readiness review meeting has been held with all key stakeholders (Compliance, IT Security, IT Ops, HR, Legal, Facilities, Department Managers). All checklist items have been reviewed. Remaining open items have escalation plans. Communication protocols during the audit have been confirmed. The team is confident in audit readiness. | ☐ Complete ☐ Not Complete ☐ In Progress ☐ N/A | 1 week prior | Compliance Officer | |

---

## Readiness Summary

| Category | Complete | Not Complete | In Progress | N/A |
|----------|----------|-------------|------------|-----|
| Governance & Documentation (1–3) | | | | |
| Evidence Readiness (4–6) | | | | |
| Technical & Operational (7–10) | | | | |
| Personnel & Logistics (11–13) | | | | |
| Self-Assessment & Final (14–15) | | | | |
| **TOTAL** | **___/15** | **___/15** | **___/15** | **___/15** |

---

## Escalation Triggers

| Condition | Action Required |
|-----------|----------------|
| Any item **Not Complete** at 4 weeks prior | Escalate to Compliance Officer; assign dedicated resource |
| Any item **Not Complete** at 2 weeks prior | Escalate to Executive Sponsor; daily tracking until resolved |
| Any item **Not Complete** at 1 week prior | Compliance Officer briefs Executive Sponsor; risk acceptance decision required |
| Prior audit findings still **Open** at audit start | Prepare written management response for the auditor explaining status and timeline |

---

## Sign-Off

| Role | Name | Signature | Date |
|------|------|-----------|------|
| Audit Coordinator | | | |
| Compliance Officer | | | |
| CISO | | | |
| Executive Sponsor | | | |

---

*Complete and file this checklist as part of the audit evidence repository (per SOP-08). Retain for a minimum of 7 years.*
