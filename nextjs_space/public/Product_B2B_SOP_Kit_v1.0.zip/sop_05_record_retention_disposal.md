# SOP-05: Record Retention and Disposal

**Document ID:** SOP-05-RRD  
**Version:** 1.0  
**Effective Date:** _______________  
**Last Reviewed:** _______________  
**Document Owner:** Compliance Officer  
**Classification:** Confidential — Internal Use Only

---

## 1. Purpose

This Standard Operating Procedure defines the processes for classifying, retaining, archiving, and securely disposing of organizational records in compliance with applicable federal and state regulations (HIPAA, SOX, GLBA, state retention laws), contractual obligations, and industry best practices. Proper record lifecycle management protects the organization during audits, litigation, and regulatory inquiries while reducing storage costs and risk exposure from retaining records beyond their useful life.

## 2. Scope

This SOP applies to:

- All organizational records regardless of format: electronic files, databases, emails, paper documents, audio/video recordings, images, and microfilm/microfiche
- All business functions: clinical/patient records, financial records, HR/personnel files, legal documents, contracts, IT logs, and operational records
- All storage locations: on-premises file servers, cloud storage, email systems, SaaS applications, physical file rooms, and offsite storage facilities
- All employees, contractors, and third parties who create, receive, maintain, or dispose of organizational records

## 3. Definitions

| Term | Definition |
|------|-----------|
| **Record** | Any documented information, regardless of format, created or received in the transaction of business that has value as evidence of the organization's activities |
| **Retention Period** | The minimum length of time a record must be maintained before it is eligible for disposal |
| **Legal Hold** | A directive to preserve all records related to pending or reasonably anticipated litigation, audit, or investigation, superseding normal retention schedules |
| **Disposition** | The final action taken on a record at the end of its retention period: destruction, transfer, or permanent archival |
| **Sanitization** | The process of rendering data unrecoverable from storage media using approved methods |

## 4. Responsibilities

| Role | Responsibilities |
|------|-----------------|
| **Compliance Officer** | Owns this SOP; maintains the retention schedule; authorizes disposition; manages legal holds |
| **Records Management Coordinator** | Executes retention processes; tracks records inventory; coordinates disposition activities |
| **Legal Counsel** | Issues and lifts legal holds; advises on regulatory retention requirements; reviews disposition requests |
| **Department Managers** | Ensure departmental compliance with retention schedules; identify records for disposition review |
| **IT Operations** | Manages electronic record storage, backup, and secure destruction of electronic media |
| **Facilities / Physical Security** | Manages physical record storage and coordinates secure physical destruction |
| **All Personnel** | Follow retention policies; do not destroy records outside approved processes; report records management concerns |

## 5. Procedures

### 5.1 Record Classification

All records must be classified upon creation or receipt according to the following categories:

| Classification | Description | Examples | Minimum Retention |
|---------------|-------------|---------|-------------------|
| **Regulatory — Healthcare** | Records required by HIPAA, state health regulations | Patient records, PHI, treatment records, consent forms, HIPAA logs | 6 years from creation or last effective date (10 years for minors in some states) |
| **Regulatory — Financial** | Records required by SOX, GLBA, SEC, IRS | Financial statements, tax records, audit workpapers, transaction records | 7 years |
| **Regulatory — Employment** | Records required by EEOC, OSHA, DOL, state employment laws | Personnel files, payroll records, I-9 forms, benefits records, OSHA logs | 3–7 years depending on record type (see detailed schedule) |
| **Legal** | Records with legal significance | Contracts, litigation files, intellectual property records, corporate governance documents | Duration of agreement + 6 years; litigation files: 7 years post-resolution |
| **Operational** | Records supporting business operations | Policies, SOPs, meeting minutes, project documentation | 5 years or until superseded + 2 years |
| **Transient** | Records with short-term value | Routine correspondence, drafts, duplicates, scheduling records | 1 year |

### 5.2 Retention Schedule Management

| Step | Action | Responsible Party | Frequency |
|------|--------|------------------|-----------|
| 2.1 | Maintain the Master Retention Schedule listing all record categories, retention periods, and regulatory citations | Compliance Officer | Continuously maintained |
| 2.2 | Review and update the Master Retention Schedule for regulatory changes | Compliance Officer / Legal | Annually or upon regulatory change |
| 2.3 | Distribute updated retention schedules to Department Managers | Records Management Coordinator | Upon each update |
| 2.4 | Conduct records inventory to identify all record repositories and their contents | Records Management Coordinator | Annually |
| 2.5 | Verify that automated retention policies in electronic systems (email, file storage, SaaS) align with the Master Schedule | IT Operations / Records Coordinator | Semi-annually |

### 5.3 Record Storage and Protection

| Requirement | Electronic Records | Physical Records |
|-------------|-------------------|-----------------|
| **Access Control** | Per SOP-02; role-based access; encryption at rest and in transit | Locked file rooms; access log; key/badge control |
| **Environmental Controls** | Redundant storage; geographically separated backups; climate-controlled data centers | Climate-controlled storage; fire suppression; flood protection |
| **Backup** | Daily incremental; weekly full; monthly offsite; annual restore testing | Offsite storage for critical records; fireproof cabinets for originals |
| **Integrity** | File integrity monitoring; version control; audit logging | Tamper-evident containers; chain of custody for sensitive records |
| **Labeling** | Metadata tags: classification, retention date, department, disposal date | Physical labels: classification, retention date, department, box/file number |

### 5.4 Legal Hold Process

| Step | Action | Responsible Party | Documentation |
|------|--------|------------------|---------------|
| 4.1 | Legal Counsel identifies a matter requiring a legal hold (litigation, investigation, audit, regulatory inquiry) | Legal Counsel | Legal Hold Memorandum |
| 4.2 | Issue a Legal Hold Notice to all custodians who may possess relevant records, specifying: matter description, types of records to preserve, preservation obligations | Legal Counsel | Legal Hold Notice (signed acknowledgment by each custodian) |
| 4.3 | Suspend all retention and disposal activities for records within the scope of the legal hold | Records Coordinator / IT | Hold implementation record |
| 4.4 | Notify IT to suspend automated deletion policies for affected systems/data | Legal / IT | Automated hold configuration log |
| 4.5 | Periodically remind custodians of their preservation obligations (quarterly or more frequently) | Legal Counsel | Reminder communications log |
| 4.6 | When the matter is resolved, Legal Counsel issues a Legal Hold Release authorizing resumption of normal retention/disposition | Legal Counsel | Legal Hold Release Notice |
| 4.7 | Records Coordinator resumes normal retention schedules for previously held records | Records Coordinator | Hold release implementation record |

### 5.5 Record Disposition and Secure Destruction

| Step | Action | Responsible Party | Documentation |
|------|--------|------------------|---------------|
| 5.1 | Records Coordinator generates a quarterly Disposition Eligibility Report listing records that have met their retention period | Records Coordinator | Disposition Eligibility Report |
| 5.2 | Verify no active legal holds apply to any records on the eligibility list | Records Coordinator / Legal | Legal hold clearance |
| 5.3 | Department Managers review and approve disposition of their departmental records | Department Managers | Signed Disposition Approval |
| 5.4 | Compliance Officer provides final authorization for destruction | Compliance Officer | Destruction Authorization |
| 5.5 | Execute destruction using approved methods (see Section 6) | IT / Facilities / Certified Vendor | Certificate of Destruction |
| 5.6 | Update the records inventory to reflect destroyed records | Records Coordinator | Updated inventory |
| 5.7 | File the Certificate of Destruction and all disposition documentation | Records Coordinator | Archived disposition file |

## 6. Approved Destruction Methods

| Media Type | Approved Method | Standard |
|-----------|----------------|----------|
| **Paper documents** | Cross-cut shredding (P-4 or higher per DIN 66399) or incineration by certified vendor | DIN 66399 / NIST SP 800-88 |
| **Hard drives (HDD)** | Degaussing followed by physical destruction (shredding or crushing) | NIST SP 800-88 Rev. 1 — Purge + Destroy |
| **Solid State Drives (SSD)** | Cryptographic erase (if supported) followed by physical destruction | NIST SP 800-88 Rev. 1 — Purge + Destroy |
| **Optical media (CD/DVD)** | Industrial shredding or incineration | NIST SP 800-88 Rev. 1 — Destroy |
| **Magnetic tape** | Degaussing followed by physical destruction | NIST SP 800-88 Rev. 1 — Purge + Destroy |
| **Cloud / SaaS data** | Verified deletion per cloud provider's data destruction procedures; obtain written confirmation | Provider's data deletion SLA; contractual terms |
| **Mobile devices** | Factory reset + cryptographic wipe; physical destruction for devices containing highly sensitive data | NIST SP 800-88 Rev. 1 |
| **Email / Electronic files** | Permanent deletion from all systems including backups within normal backup rotation cycle | Organization policy |

## 7. Documentation Requirements

- [ ] Master Retention Schedule (current version)
- [ ] Records Inventory (updated annually)
- [ ] Legal Hold Notices and signed custodian acknowledgments
- [ ] Legal Hold Release Notices
- [ ] Disposition Eligibility Reports (quarterly)
- [ ] Signed Disposition Approvals (Department Managers)
- [ ] Destruction Authorizations (Compliance Officer)
- [ ] Certificates of Destruction (from vendor or internal team)
- [ ] Chain of Custody Records for records transferred to destruction
- [ ] Vendor contracts and certifications for destruction services

**Retention Period for Disposition Records:** Certificates of Destruction and related disposition documentation must be retained **permanently** or for a minimum of **10 years**.

## 8. Key Performance Indicators

| Metric | Target |
|--------|--------|
| Retention schedule compliance rate | 100% |
| Disposition review completion (quarterly) | 100% |
| Legal hold implementation within 24 hours of issuance | 100% |
| Certificate of Destruction obtained for every destruction event | 100% |
| Records inventory accuracy (annual audit) | > 95% |

## 9. Related Documents

- Information Security Policy
- SOP-01: Data Breach Response
- SOP-07: Physical Security
- Legal Hold Policy
- Data Classification Policy
- Vendor Management Policy

## 10. Review Schedule

| Review Activity | Frequency | Responsible Party |
|----------------|-----------|------------------|
| Full SOP review and update | Annually | Compliance Officer |
| Master Retention Schedule review | Annually or upon regulatory change | Compliance / Legal |
| Records inventory audit | Annually | Records Coordinator |
| Destruction vendor contract review | Annually | Procurement / Compliance |
| Legal hold process audit | Semi-annually | Legal / Compliance |

## 11. Revision History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | _____________ | _____________ | Initial release |

## 12. Approval

| Role | Name | Signature | Date |
|------|------|-----------|------|
| Compliance Officer | | | |
| General Counsel | | | |
| CISO | | | |
| CFO | | | |
