# Industry Module: HIPAA / Healthcare Compliance

**Document ID:** MOD-HIPAA-HC  
**Version:** 1.0  
**Effective Date:** _______________  
**Last Reviewed:** _______________  
**Document Owner:** Privacy Officer / HIPAA Compliance Officer  
**Classification:** Confidential — Internal Use Only

---

## 1. Purpose

This module supplements the core SOP toolkit with healthcare-specific protocols required for compliance with the Health Insurance Portability and Accountability Act (HIPAA), the HITECH Act, and applicable state health information privacy laws. It provides actionable guidance for covered entities and business associates to protect Protected Health Information (PHI) across all operational processes.

## 2. Applicability

This module applies to organizations that are:

- **Covered Entities** under HIPAA: health plans, healthcare clearinghouses, and healthcare providers who transmit health information electronically
- **Business Associates** of covered entities: entities that create, receive, maintain, or transmit PHI on behalf of a covered entity
- **Subcontractors** of business associates who handle PHI

## 3. Regulatory Framework Reference

| Regulation | Key Requirements | Enforcement Agency |
|-----------|-----------------|-------------------|
| **HIPAA Privacy Rule** (45 CFR Part 160, Part 164 Subpart E) | Establishes standards for the use and disclosure of PHI; patient rights regarding their health information | HHS Office for Civil Rights (OCR) |
| **HIPAA Security Rule** (45 CFR Part 164 Subpart C) | Requires administrative, physical, and technical safeguards for electronic PHI (ePHI) | HHS OCR |
| **HIPAA Breach Notification Rule** (45 CFR Part 164 Subpart D) | Requires notification to individuals, HHS, and media (if >500) following a breach of unsecured PHI | HHS OCR |
| **HITECH Act** | Strengthens HIPAA enforcement; extends direct liability to business associates; increases penalties | HHS OCR |
| **State Laws** | Many states have health information privacy laws that may be more stringent than HIPAA (e.g., CA CMIA, TX HB 300) | State AGs / Health Departments |

## 4. PHI-Specific Data Handling Protocols

### 4.1 Identification of PHI

PHI includes any individually identifiable health information that relates to:
- An individual's past, present, or future physical or mental health condition
- The provision of healthcare to an individual
- Past, present, or future payment for healthcare

**The 18 HIPAA Identifiers:** Any health information linked to the following identifiers constitutes PHI:

| # | Identifier | # | Identifier |
|---|-----------|---|-----------|
| 1 | Names | 10 | Account numbers |
| 2 | Geographic data (smaller than state) | 11 | Certificate/license numbers |
| 3 | Dates (except year) related to individual | 12 | Vehicle identifiers and serial numbers |
| 4 | Phone numbers | 13 | Device identifiers and serial numbers |
| 5 | Fax numbers | 14 | Web URLs |
| 6 | Email addresses | 15 | IP addresses |
| 7 | Social Security numbers | 16 | Biometric identifiers |
| 8 | Medical record numbers | 17 | Full-face photographs |
| 9 | Health plan beneficiary numbers | 18 | Any other unique identifying number |

### 4.2 Minimum Necessary Standard

| Principle | Implementation |
|-----------|---------------|
| **Use** | Limit PHI use to the minimum necessary for the intended purpose; implement role-based access policies |
| **Disclosure** | Before disclosing PHI, verify the request is authorized and limit disclosure to the minimum data needed |
| **Request** | When requesting PHI from another entity, request only the minimum necessary |
| **Exceptions** | The minimum necessary standard does NOT apply to: treatment disclosures between providers, disclosures to the individual, disclosures authorized by the individual, disclosures to HHS for compliance investigations, disclosures required by law |

### 4.3 PHI Access and Disclosure Controls

| Scenario | Required Action | SOP Reference |
|----------|----------------|---------------|
| Employee requests access to PHI for treatment | Verify role authorization; log access; apply minimum necessary | SOP-02 |
| Patient requests access to their records | Verify identity; fulfill within 30 days; may charge reasonable fee | Section 5.1 below |
| Third-party requests PHI with patient authorization | Verify authorization form validity; disclose only what is authorized; log | Section 5.2 below |
| Law enforcement requests PHI | Route to Privacy Officer and Legal; comply only per HIPAA § 164.512(f) | Legal Counsel |
| Research use of PHI | Requires IRB/Privacy Board approval or valid authorization or de-identification | Privacy Officer |
| Business Associate requests PHI | Verify active BAA; verify purpose is within BAA scope; log | SOP-06 |

## 5. HIPAA-Specific Procedures

### 5.1 Patient Rights Management

| Right | Procedure | Timeline |
|-------|-----------|----------|
| **Right to Access** | Patient submits written request; verify identity; provide copies in requested format (if readily producible); may charge reasonable cost-based fee | 30 days (one 30-day extension permitted with written notice) |
| **Right to Amend** | Patient submits written amendment request with reason; if accepted, amend and notify; if denied, provide written denial with appeal rights | 60 days (one 30-day extension permitted) |
| **Right to Accounting of Disclosures** | Patient requests an accounting; provide all non-exempt disclosures for the prior 6 years | 60 days (one 30-day extension permitted) |
| **Right to Request Restrictions** | Patient requests restrictions on use/disclosure; organization may agree or decline (exception: must restrict if patient pays out of pocket in full and requests no disclosure to health plan for that service) | Reasonable timeframe |
| **Right to Confidential Communications** | Patient requests alternative communication method or location; accommodate if reasonable | Reasonable timeframe |
| **Right to Notice of Privacy Practices** | Provide NPP at first service delivery; make available on request; post prominently in facility and on website | At first service; on request |

### 5.2 Authorization Management

Valid HIPAA authorization for use/disclosure of PHI must contain:

- [ ] Specific description of PHI to be used/disclosed
- [ ] Name of person(s) authorized to make the disclosure
- [ ] Name of person(s) to whom disclosure is made
- [ ] Purpose of the use/disclosure
- [ ] Expiration date or event
- [ ] Individual's signature and date
- [ ] If signed by a personal representative: description of their authority

**Authorization is NOT required for:** Treatment, Payment, and Healthcare Operations (TPO); disclosures required by law; public health activities; judicial proceedings with court order; law enforcement per § 164.512(f).

### 5.3 Business Associate Management (HIPAA-Specific)

Supplementing SOP-06 (Vendor Assessment):

| Requirement | Action |
|-------------|--------|
| **BAA Execution** | A HIPAA-compliant BAA must be executed with every business associate BEFORE any PHI is shared or accessible |
| **BAA Required Terms** | Permitted/required uses and disclosures of PHI; obligation to safeguard PHI; obligation to report breaches; obligation to ensure subcontractors agree to same restrictions; make PHI available for patient access; return or destroy PHI at termination; make records available to HHS |
| **Subcontractor Requirements** | Business associates must obtain BAAs from their subcontractors before sharing PHI |
| **BAA Review** | Review all active BAAs annually; update for regulatory changes; verify BA compliance |
| **BAA Termination** | If a BA violates the BAA and cure is not feasible, terminate the agreement; if termination is not feasible, report to HHS |

### 5.4 Breach Notification — HIPAA Specific

Supplementing SOP-01 (Data Breach Response):

| Requirement | HIPAA Standard |
|-------------|---------------|
| **Breach Presumption** | Any impermissible use or disclosure of PHI is presumed to be a breach unless the organization demonstrates a low probability that PHI was compromised based on the 4-factor risk assessment |
| **4-Factor Risk Assessment** | (1) Nature and extent of PHI involved; (2) Unauthorized person who used or received the PHI; (3) Whether PHI was actually acquired or viewed; (4) Extent to which risk has been mitigated |
| **Individual Notification** | Written notice to each affected individual within 60 days of discovery; must include: description of breach, types of PHI, steps to protect themselves, what organization is doing, contact information |
| **HHS Notification** | Breach of <500 individuals: annual log submission to HHS (within 60 days of calendar year end). Breach of ≥500 individuals: notify HHS within 60 days of discovery |
| **Media Notification** | Breach affecting ≥500 residents of a single state/jurisdiction: notify prominent media outlets in that state within 60 days |
| **Business Associate Obligation** | BA must notify the covered entity of a breach within the timeframe specified in the BAA (recommended: within 24–48 hours) |

### 5.5 HIPAA Security Rule — Technical Safeguards Checklist

| Safeguard | Required/Addressable | Implementation Requirement |
|-----------|---------------------|---------------------------|
| Unique user identification | **Required** | Assign a unique identifier to each user accessing ePHI |
| Emergency access procedure | **Required** | Establish procedures for obtaining ePHI during emergencies |
| Automatic logoff | **Addressable** | Implement electronic procedures that terminate sessions after inactivity |
| Encryption and decryption | **Addressable** | Implement encryption for ePHI at rest (strongly recommended: AES-256) |
| Audit controls | **Required** | Implement mechanisms to record and examine activity in systems containing ePHI |
| Integrity controls | **Addressable** | Implement mechanisms to authenticate ePHI and detect unauthorized alteration |
| Transmission security | **Required** | Implement encryption for ePHI in transit (required: TLS 1.2+ for all transmissions) |
| Authentication | **Required** | Verify identity of persons seeking access to ePHI |
| Access controls | **Required** | Implement technical policies limiting access to ePHI to authorized persons |

### 5.6 HIPAA Training Requirements

| Training Topic | Audience | Frequency | Tracking |
|---------------|----------|-----------|----------|
| HIPAA Privacy Rule overview and patient rights | All workforce members | Upon hire + annually | Training completion log |
| HIPAA Security Rule and ePHI safeguards | All workforce members with ePHI access | Upon hire + annually | Training completion log |
| PHI handling, minimum necessary, and de-identification | Clinical and administrative staff | Upon hire + annually | Training completion log |
| Breach recognition and reporting | All workforce members | Upon hire + annually | Training completion log |
| Role-specific HIPAA training (privacy officer, security officer, management) | Designated roles | Upon role assignment + annually | Training completion log |
| Sanctions awareness (consequences of violations) | All workforce members | Upon hire + annually | Signed acknowledgment |

### 5.7 HIPAA Sanctions Policy

Violations of HIPAA policies must result in documented, consistent sanctions:

| Violation Severity | Examples | Sanction Range |
|-------------------|---------|----------------|
| **Unintentional/Minor** | Misdirected fax containing PHI (immediately recovered); accessing one's own medical record | Verbal warning + additional training |
| **Negligent** | Leaving PHI unattended in public area; sharing login credentials; failing to encrypt a laptop containing ePHI | Written warning + mandatory training + access review |
| **Serious** | Accessing PHI without authorization (snooping); disabling security controls; repeated negligent violations | Suspension + formal investigation + potential termination |
| **Willful/Malicious** | Selling PHI; intentional unauthorized disclosure for personal gain; identity theft using PHI | Termination + referral to law enforcement + report to HHS |

## 6. HIPAA Compliance Monitoring

| Activity | Frequency | Responsible Party |
|----------|-----------|------------------|
| HIPAA risk assessment | Annually | HIPAA Security Officer |
| Access audit for ePHI systems | Quarterly | IT Security |
| PHI inventory and data flow mapping | Annually | Privacy Officer |
| BAA inventory review | Annually | Compliance |
| Notice of Privacy Practices review | Annually | Privacy Officer |
| Sanctions log review | Quarterly | Privacy Officer / HR |
| Breach log review and submission to HHS | Annually (by Feb 28) | Privacy Officer |

## 7. Documentation Requirements (HIPAA-Specific)

- [ ] HIPAA Risk Assessment (current, dated within 12 months)
- [ ] Notice of Privacy Practices (current version; proof of distribution)
- [ ] All signed patient authorizations
- [ ] Accounting of Disclosures log
- [ ] Business Associate Agreement inventory (all active BAAs)
- [ ] HIPAA training completion records (all workforce members)
- [ ] Signed sanctions policy acknowledgments
- [ ] Breach log (including risk assessments for each incident)
- [ ] HHS breach notification submissions
- [ ] HIPAA policies and procedures (current versions with revision history)

**HIPAA Retention Requirement:** All HIPAA-related documentation must be retained for **6 years from the date of creation or the date when the document was last in effect**, whichever is later.

## 8. Related Core SOPs

| Core SOP | HIPAA-Specific Supplement |
|----------|--------------------------|
| SOP-01: Data Breach Response | Section 5.4 — HIPAA breach notification requirements |
| SOP-02: Access Control | Section 5.5 — ePHI technical safeguards |
| SOP-03: Onboarding/Offboarding | Section 5.6 — HIPAA training requirements |
| SOP-05: Record Retention | Section 7 — HIPAA 6-year retention requirement |
| SOP-06: Vendor Assessment | Section 5.3 — BAA requirements |
| SOP-08: Audit Preparation | Use this module's monitoring activities as audit evidence |

## 9. Revision History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | _____________ | _____________ | Initial release |

## 10. Approval

| Role | Name | Signature | Date |
|------|------|-----------|------|
| HIPAA Privacy Officer | | | |
| HIPAA Security Officer | | | |
| Chief Compliance Officer | | | |
| General Counsel | | | |
