# QA Checklist: Sensitive Data Handling

**Document ID:** QA-DH-001  
**Version:** 1.0  
**Effective Date:** _______________  
**Classification:** Confidential — Internal Use Only

---

## Purpose

This checklist provides a 15-point verification process for ensuring that sensitive data (PHI, PII, financial data, attorney-client privileged information) is handled in compliance with organizational policies and regulatory requirements at every stage of its lifecycle. Use this checklist during routine quality assurance reviews, before system deployments, and as part of audit preparation.

---

## Instructions

- Complete this checklist for each system, process, or project that handles sensitive data
- Mark each item: **✅ Pass** | **❌ Fail** | **⚠️ Partial** | **N/A Not Applicable**
- All **Fail** items require a corrective action with owner and deadline
- Retain completed checklists as compliance evidence

---

## Reviewer Information

| Field | Value |
|-------|-------|
| **Reviewer Name** | |
| **Review Date** | |
| **System / Process Reviewed** | |
| **Data Types in Scope** | ☐ PHI ☐ PII ☐ Financial/NPI ☐ Privileged ☐ Confidential ☐ Other: _________ |
| **Department / Business Unit** | |
| **Review Type** | ☐ Routine QA ☐ Pre-Deployment ☐ Audit Preparation ☐ Incident-Triggered ☐ New Vendor |

---

## Data Handling Verification Checklist

### Data Classification and Inventory

| # | Verification Item | Status | Evidence / Notes | Corrective Action (if Fail) | Owner | Deadline |
|---|------------------|--------|-----------------|---------------------------|-------|----------|
| 1 | **Data Classification Applied:** All sensitive data elements within the system/process have been formally classified per the Data Classification Policy (e.g., Confidential, Restricted, PHI, PII, NPI). Data owners are designated for each dataset. | ☐ Pass ☐ Fail ☐ Partial ☐ N/A | | | | |
| 2 | **Data Inventory Current:** A complete inventory of sensitive data exists, documenting: data types, storage locations (including backups and replicas), data flows (ingress, processing, egress), third parties with access, and retention periods. Inventory has been reviewed within the last 12 months. | ☐ Pass ☐ Fail ☐ Partial ☐ N/A | | | | |

### Access Controls

| # | Verification Item | Status | Evidence / Notes | Corrective Action (if Fail) | Owner | Deadline |
|---|------------------|--------|-----------------|---------------------------|-------|----------|
| 3 | **Least Privilege Enforced:** Access to sensitive data is restricted to personnel with a documented business need. Role-based access control (RBAC) is implemented. No users have excessive or unnecessary access to sensitive data. Verified by reviewing current access lists against role requirements. | ☐ Pass ☐ Fail ☐ Partial ☐ N/A | | | | |
| 4 | **Multi-Factor Authentication (MFA):** MFA is enabled and enforced for all user accounts that access systems containing sensitive data, including remote access, administrative access, and cloud portals. No exceptions exist without documented risk acceptance. | ☐ Pass ☐ Fail ☐ Partial ☐ N/A | | | | |
| 5 | **Access Reviews Completed:** Periodic access reviews (quarterly for sensitive systems) have been completed on schedule. Manager certifications are documented. Identified excess access has been revoked within the required timeframe. | ☐ Pass ☐ Fail ☐ Partial ☐ N/A | | | | |

### Encryption and Transmission

| # | Verification Item | Status | Evidence / Notes | Corrective Action (if Fail) | Owner | Deadline |
|---|------------------|--------|-----------------|---------------------------|-------|----------|
| 6 | **Encryption at Rest:** All sensitive data at rest is encrypted using approved algorithms (AES-256 or equivalent). This includes databases, file storage, backups, and removable media. Encryption keys are managed per the Key Management Policy (rotated, access-controlled, separated from data). | ☐ Pass ☐ Fail ☐ Partial ☐ N/A | | | | |
| 7 | **Encryption in Transit:** All sensitive data in transit is encrypted using TLS 1.2 or higher. No sensitive data is transmitted via unencrypted channels (HTTP, FTP, unencrypted email). Secure file transfer mechanisms (SFTP, encrypted portals) are used for file exchanges. | ☐ Pass ☐ Fail ☐ Partial ☐ N/A | | | | |

### Data Processing and Use

| # | Verification Item | Status | Evidence / Notes | Corrective Action (if Fail) | Owner | Deadline |
|---|------------------|--------|-----------------|---------------------------|-------|----------|
| 8 | **Minimum Necessary / Data Minimization:** Only the minimum data necessary for the specific purpose is collected, processed, displayed, and retained. No excessive data collection occurs. Sensitive data is masked, redacted, or de-identified when full data is not required (e.g., in reports, non-production environments, analytics). | ☐ Pass ☐ Fail ☐ Partial ☐ N/A | | | | |
| 9 | **Non-Production Environment Controls:** Sensitive data is NOT present in development, testing, staging, or training environments unless: (a) it is de-identified/anonymized, OR (b) a documented exception exists with equivalent security controls applied. Production data is not cloned to non-production without approval and safeguards. | ☐ Pass ☐ Fail ☐ Partial ☐ N/A | | | | |

### Logging, Monitoring, and Audit Trail

| # | Verification Item | Status | Evidence / Notes | Corrective Action (if Fail) | Owner | Deadline |
|---|------------------|--------|-----------------|---------------------------|-------|----------|
| 10 | **Audit Logging Enabled:** All access to sensitive data is logged with: user identity, timestamp, action performed (read, write, delete, export), data accessed, and source IP/system. Logs are tamper-protected (write-once or integrity-monitored). Logs are retained per the retention policy (minimum 1 year; 6 years for HIPAA systems). | ☐ Pass ☐ Fail ☐ Partial ☐ N/A | | | | |
| 11 | **Monitoring and Alerting:** Automated monitoring is in place for: unusual access patterns, bulk data exports, access outside business hours, privilege escalation, and failed authentication attempts. Alerts are routed to the SOC or security team with defined response SLAs. | ☐ Pass ☐ Fail ☐ Partial ☐ N/A | | | | |

### Retention, Disposal, and Third Parties

| # | Verification Item | Status | Evidence / Notes | Corrective Action (if Fail) | Owner | Deadline |
|---|------------------|--------|-----------------|---------------------------|-------|----------|
| 12 | **Retention Policy Compliance:** Sensitive data is retained only for the period required by regulation, contract, or business need as defined in the Master Retention Schedule. No sensitive data is retained beyond its required retention period without documented justification. Automated retention/deletion policies are configured where feasible. | ☐ Pass ☐ Fail ☐ Partial ☐ N/A | | | | |
| 13 | **Secure Disposal:** Sensitive data that has reached the end of its retention period is destroyed using approved methods (per SOP-05 and NIST SP 800-88). Certificates of destruction are obtained and filed. No sensitive data remains on decommissioned hardware, media, or in terminated cloud services. | ☐ Pass ☐ Fail ☐ Partial ☐ N/A | | | | |
| 14 | **Third-Party Data Handling:** All third parties with access to sensitive data have: (a) executed appropriate agreements (BAA, DPA, NDA); (b) undergone risk assessment per SOP-06; (c) agreed to equivalent security controls; (d) committed to breach notification within contractual SLAs. Sub-processors are identified and approved. | ☐ Pass ☐ Fail ☐ Partial ☐ N/A | | | | |

### Incident Preparedness

| # | Verification Item | Status | Evidence / Notes | Corrective Action (if Fail) | Owner | Deadline |
|---|------------------|--------|-----------------|---------------------------|-------|----------|
| 15 | **Breach Response Readiness:** Personnel who handle sensitive data know how to report a suspected breach (per SOP-01 and SOP-04). The incident response plan covers the specific data types in scope. Notification procedures and templates are current. Contact lists are up-to-date. A tabletop exercise has been conducted within the last 12 months. | ☐ Pass ☐ Fail ☐ Partial ☐ N/A | | | | |

---

## Review Summary

| Category | Pass | Fail | Partial | N/A |
|----------|------|------|---------|-----|
| Data Classification & Inventory (1–2) | | | | |
| Access Controls (3–5) | | | | |
| Encryption & Transmission (6–7) | | | | |
| Data Processing & Use (8–9) | | | | |
| Logging & Monitoring (10–11) | | | | |
| Retention, Disposal & Third Parties (12–14) | | | | |
| Incident Preparedness (15) | | | | |
| **TOTAL** | **___/15** | **___/15** | **___/15** | **___/15** |

---

## Overall Assessment

| Assessment | Criteria |
|-----------|---------|
| ☐ **Pass** | All items Pass or N/A; no Fail or Partial items |
| ☐ **Conditional Pass** | No Critical Fail items; Partial items have corrective actions with deadlines within 30 days |
| ☐ **Fail** | One or more Fail items exist; corrective actions required before sensitive data handling can proceed/continue |

---

## Sign-Off

| Role | Name | Signature | Date |
|------|------|-----------|------|
| Reviewer | | | |
| System / Process Owner | | | |
| Compliance Officer | | | |

---

*Retain this completed checklist for a minimum of 6 years as compliance evidence.*
