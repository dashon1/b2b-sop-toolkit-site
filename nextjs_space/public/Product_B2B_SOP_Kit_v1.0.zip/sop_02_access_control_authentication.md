# SOP-02: Access Control and Authentication

**Document ID:** SOP-02-ACA  
**Version:** 1.0  
**Effective Date:** _______________  
**Last Reviewed:** _______________  
**Document Owner:** Chief Information Security Officer (CISO)  
**Classification:** Confidential — Internal Use Only

---

## 1. Purpose

This Standard Operating Procedure defines the policies, processes, and controls for managing logical and physical access to organizational information systems, applications, data repositories, and facilities. It ensures that access is granted on a least-privilege, need-to-know basis and that authentication mechanisms meet or exceed regulatory requirements (HIPAA, SOC 2, PCI DSS, NIST 800-53).

## 2. Scope

This SOP applies to:

- All information systems, applications, databases, network infrastructure, cloud services, and physical facilities
- All users: employees, contractors, temporary staff, vendors, consultants, and automated service accounts
- All access methods: local, remote (VPN, RDP), API, mobile, and physical badge access
- All environments: production, staging, development, disaster recovery, and test

## 3. Definitions

| Term | Definition |
|------|-----------|
| **Least Privilege** | The principle that users are granted only the minimum access rights necessary to perform their job functions |
| **Role-Based Access Control (RBAC)** | Access control model where permissions are assigned to roles, and users are assigned to roles |
| **Multi-Factor Authentication (MFA)** | Authentication requiring two or more independent verification factors |
| **Privileged Access** | Elevated access rights that permit administrative functions, configuration changes, or access to sensitive data |
| **Service Account** | A non-human account used by applications, scripts, or automated processes to authenticate and access resources |
| **Access Review** | Periodic evaluation of user access rights to verify continued appropriateness |

## 4. Responsibilities

| Role | Responsibilities |
|------|-----------------|
| **CISO / Security Officer** | Owns this SOP; approves access control policies; authorizes exceptions |
| **IT Security Team** | Implements and monitors access controls; manages authentication systems; conducts access reviews |
| **Identity and Access Management (IAM) Team** | Provisions and deprovisions accounts; manages directory services; maintains role definitions |
| **System/Application Owners** | Define access requirements for their systems; approve access requests; participate in access reviews |
| **Department Managers** | Submit and approve access requests for their staff; certify access during periodic reviews |
| **Human Resources** | Initiates onboarding/offboarding access workflows; notifies IT of role changes and terminations |
| **All Users** | Safeguard credentials; report unauthorized access; comply with authentication requirements |

## 5. Procedures

### 5.1 Account Provisioning

| Step | Action | Responsible Party | Documentation |
|------|--------|------------------|---------------|
| 1.1 | HR submits a New User Access Request upon hire confirmation, including: full name, department, job title, start date, manager, and required systems/applications | Human Resources | New User Access Request Form |
| 1.2 | Department Manager reviews and approves the requested access levels, specifying the role(s) and systems needed | Department Manager | Approved Access Request |
| 1.3 | IAM Team creates user accounts in Active Directory / Identity Provider based on approved role templates | IAM Team | Account creation log |
| 1.4 | IAM Team provisions application-specific access based on the RBAC role matrix | IAM Team | Provisioning log |
| 1.5 | IAM Team configures MFA enrollment and sends activation instructions to the user via secure channel | IAM Team | MFA enrollment record |
| 1.6 | User completes MFA enrollment and sets initial password following the password policy | New User | MFA confirmation; password set log |
| 1.7 | IAM Team verifies all access is provisioned correctly against the approved request | IAM Team | Verification checklist |
| 1.8 | System/Application Owners confirm access is appropriate for the assigned role | System Owners | Owner sign-off |

### 5.2 Authentication Standards

| Requirement | Standard | Applicability |
|-------------|----------|--------------|
| **Password Length** | Minimum 14 characters | All user accounts |
| **Password Complexity** | Must include uppercase, lowercase, numeric, and special characters | All user accounts |
| **Password Expiration** | Every 90 days (or per NIST guidance: no expiration with MFA + breach monitoring) | All user accounts |
| **Password History** | Cannot reuse last 12 passwords | All user accounts |
| **Account Lockout** | Lock after 5 consecutive failed attempts; 30-minute lockout or manual unlock | All user accounts |
| **MFA Requirement** | Required for all remote access, privileged access, access to systems containing PHI/PII, and cloud administrative consoles | Specified systems |
| **Session Timeout** | Automatic session lock after 15 minutes of inactivity | All workstations and applications |
| **Service Account Authentication** | Certificate-based or managed secret with automated rotation every 90 days | All service accounts |

### 5.3 Access Modification

| Step | Action | Responsible Party | Documentation |
|------|--------|------------------|---------------|
| 3.1 | When an employee changes roles, departments, or responsibilities, the Department Manager submits an Access Modification Request | Department Manager | Access Modification Request Form |
| 3.2 | Previous access rights are reviewed against new role requirements; unnecessary access is identified for removal | IAM Team / Security | Access comparison report |
| 3.3 | New access rights are provisioned according to the new role template | IAM Team | Provisioning update log |
| 3.4 | Previous access rights that are no longer required are revoked within 3 business days | IAM Team | Deprovisioning log |
| 3.5 | System/Application Owners verify the updated access is appropriate | System Owners | Owner sign-off |

### 5.4 Account Deprovisioning

| Step | Action | Responsible Party | Documentation |
|------|--------|------------------|---------------|
| 4.1 | HR notifies IT Security and IAM of the employee's termination or end-of-contract date via the Offboarding Notification | Human Resources | Offboarding Notification |
| 4.2 | **Voluntary termination:** Disable all access on the last day of employment by end of business | IAM Team | Deprovisioning log |
| 4.3 | **Involuntary termination:** Disable all access immediately upon notification, before or concurrent with the termination meeting | IAM Team | Emergency deprovisioning log |
| 4.4 | Disable Active Directory / IdP account; revoke VPN, SSO, and all application access tokens | IAM Team | System-level deprovisioning log |
| 4.5 | Collect physical access credentials: badges, keys, fobs, hardware tokens | Facilities / HR | Asset return checklist |
| 4.6 | Revoke remote device access; initiate remote wipe for company-managed mobile devices if applicable | IT Operations | Device management log |
| 4.7 | Transfer ownership of shared resources, mailboxes, and files to designated successor per manager instruction | IAM Team / IT | Transfer log |
| 4.8 | Verify complete deprovisioning across all systems within 24 hours | IT Security | Deprovisioning verification report |

### 5.5 Privileged Access Management

| Step | Action | Responsible Party | Documentation |
|------|--------|------------------|---------------|
| 5.1 | All privileged access requests must be submitted with business justification and approved by the CISO or delegate | Requesting Party / CISO | Privileged Access Request Form |
| 5.2 | Privileged accounts must be separate from standard user accounts (no dual-purpose accounts) | IAM Team | Account inventory |
| 5.3 | All privileged sessions must be logged and monitored; session recording is required for critical infrastructure access | IT Security | Session logs / recordings |
| 5.4 | Privileged access credentials must be stored in an approved enterprise password vault / PAM solution | IT Security | Vault enrollment record |
| 5.5 | Privileged access must be reviewed monthly by the CISO or delegate | CISO / IT Security | Monthly privileged access review |
| 5.6 | Emergency ("break glass") accounts must be sealed, with usage triggering an automatic alert and mandatory post-use review | IT Security | Break glass usage log |

### 5.6 Periodic Access Reviews

| Step | Action | Responsible Party | Documentation |
|------|--------|------------------|---------------|
| 6.1 | IT Security generates a comprehensive access report for each system/application quarterly | IT Security | Access report |
| 6.2 | System/Application Owners and Department Managers review all user access for their areas and certify or flag exceptions | Owners / Managers | Access certification form |
| 6.3 | Flagged access (unnecessary, excessive, or orphaned accounts) is revoked within 5 business days | IAM Team | Revocation log |
| 6.4 | IT Security compiles the review results and exception report for compliance documentation | IT Security | Quarterly Access Review Report |
| 6.5 | Compliance Officer reviews the report and files it in the compliance evidence repository | Compliance Officer | Filed review record |

## 6. Emergency Access Procedures

In the event that standard access processes cannot be followed due to a critical system emergency:

1. The requesting party contacts the on-call Security Operations team with the emergency justification
2. Security Operations grants temporary access via the break-glass procedure
3. All emergency access is logged with: requester, authorizer, systems accessed, time granted, time revoked
4. Emergency access is revoked within **4 hours** or upon resolution of the emergency, whichever is sooner
5. A post-emergency review is conducted within **24 hours** to evaluate whether the access was appropriate

## 7. Documentation Requirements

- [ ] New User Access Request Forms (approved)
- [ ] Access Modification Request Forms (approved)
- [ ] Offboarding Notification and Deprovisioning Records
- [ ] Privileged Access Request Forms (approved by CISO)
- [ ] MFA Enrollment and Configuration Records
- [ ] Quarterly Access Review Reports with Manager Certifications
- [ ] Privileged Access Monthly Review Reports
- [ ] Emergency / Break-Glass Access Logs and Post-Use Reviews
- [ ] Role-Based Access Control Matrix (current)
- [ ] Service Account Inventory and Credential Rotation Records

**Retention Period:** All access control records must be retained for a minimum of **6 years** or as required by applicable regulations.

## 8. Key Performance Indicators

| Metric | Target |
|--------|--------|
| Account provisioning completion time | Within 1 business day of start date |
| Account deprovisioning (voluntary) | By end of business on last day |
| Account deprovisioning (involuntary) | Within 1 hour of notification |
| Quarterly access review completion rate | 100% |
| MFA enrollment rate | 100% for all required accounts |
| Orphaned account detection and removal | Within 5 business days of identification |

## 9. Related Documents

- Information Security Policy
- Acceptable Use Policy
- SOP-03: Employee Onboarding and Offboarding
- SOP-07: Physical Security
- Password Policy
- Remote Access Policy

## 10. Review Schedule

| Review Activity | Frequency | Responsible Party |
|----------------|-----------|------------------|
| Full SOP review and update | Annually | CISO / IT Security Lead |
| RBAC role matrix review | Semi-annually | IAM Team / System Owners |
| User access certifications | Quarterly | Department Managers / System Owners |
| Privileged access review | Monthly | CISO or Delegate |
| Authentication technology assessment | Annually | IT Security |

## 11. Revision History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | _____________ | _____________ | Initial release |

## 12. Approval

| Role | Name | Signature | Date |
|------|------|-----------|------|
| CISO | | | |
| CTO / CIO | | | |
| Compliance Officer | | | |
| HR Director | | | |
