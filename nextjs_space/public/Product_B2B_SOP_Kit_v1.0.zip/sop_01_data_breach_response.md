# SOP-01: Data Breach Response

**Document ID:** SOP-01-DBR  
**Version:** 1.0  
**Effective Date:** _______________  
**Last Reviewed:** _______________  
**Document Owner:** Chief Information Security Officer (CISO)  
**Classification:** Confidential — Internal Use Only

---

## 1. Purpose

This Standard Operating Procedure establishes a structured, repeatable, and legally defensible process for detecting, containing, investigating, and remediating data breaches. It ensures the organization meets notification obligations under applicable regulations (HIPAA, GLBA, state breach notification laws, GDPR where applicable) and minimizes operational, financial, and reputational damage.

## 2. Scope

This SOP applies to:

- All employees, contractors, temporary staff, and third-party service providers with access to organizational data systems
- All categories of data: Protected Health Information (PHI), Personally Identifiable Information (PII), financial records, intellectual property, and any data classified as Confidential or above
- All environments: on-premises infrastructure, cloud services, hybrid deployments, mobile devices, and paper records
- All locations where organizational data is processed, stored, or transmitted

## 3. Definitions

| Term | Definition |
|------|-----------|
| **Data Breach** | Unauthorized acquisition, access, use, or disclosure of protected data that compromises its security, confidentiality, or integrity |
| **Security Incident** | Any event that potentially threatens the confidentiality, integrity, or availability of information assets (may or may not constitute a breach) |
| **Breach Coordinator** | Designated individual responsible for managing the end-to-end breach response process |
| **Notification Threshold** | The regulatory or contractual criteria that trigger mandatory external notification |
| **Containment** | Actions taken to limit the scope and impact of a breach |
| **Forensic Preservation** | The process of collecting and preserving digital evidence in a legally admissible manner |

## 4. Responsibilities

| Role | Responsibilities |
|------|-----------------|
| **CISO / Security Officer** | Owns this SOP; activates the Incident Response Team; authorizes containment actions; approves external communications |
| **Breach Coordinator** | Manages the response timeline; coordinates across departments; maintains the breach log; ensures notification deadlines are met |
| **IT / Security Operations** | Performs technical containment, forensic analysis, evidence preservation, and system restoration |
| **Legal Counsel** | Determines notification obligations; reviews all external communications; manages regulatory correspondence; advises on liability |
| **Compliance Officer** | Verifies regulatory requirements are met; updates compliance logs; coordinates with auditors |
| **Human Resources** | Manages workforce-related breaches; coordinates employee notifications; handles disciplinary actions if applicable |
| **Communications / PR** | Drafts external statements; manages media inquiries; coordinates customer-facing communications |
| **Executive Leadership** | Receives escalation briefings; authorizes resource allocation; approves public statements |

## 5. Procedures

### 5.1 Phase 1 — Detection and Initial Assessment

**Timeline:** Within 1 hour of discovery

| Step | Action | Responsible Party | Documentation |
|------|--------|------------------|---------------|
| 1.1 | Identify the potential breach through monitoring tools, user reports, third-party notification, or audit findings | Any Employee / Security Operations | Initial Incident Report Form |
| 1.2 | Report the incident immediately to the Security Operations Center (SOC) or designated security contact via the Incident Hotline or secure email | Discovering Party | Incident ticket created |
| 1.3 | SOC performs initial triage: classify severity (Critical / High / Medium / Low) based on data type, volume, and exposure scope | Security Operations | Severity Classification Matrix |
| 1.4 | If severity is Medium or above, activate the Breach Coordinator and notify the CISO | Security Operations | Activation log entry |
| 1.5 | Breach Coordinator convenes the Incident Response Team within 2 hours of activation | Breach Coordinator | Meeting minutes / attendance log |
| 1.6 | Preserve all initial evidence: system logs, access records, screenshots, email headers, physical access logs | IT / Security Operations | Chain of custody form initiated |

### 5.2 Phase 2 — Containment

**Timeline:** Within 4 hours of confirmed breach

| Step | Action | Responsible Party | Documentation |
|------|--------|------------------|---------------|
| 2.1 | Implement immediate containment: isolate affected systems, disable compromised accounts, block suspicious IP addresses, revoke access tokens | IT / Security Operations | Containment action log |
| 2.2 | Determine if the breach is ongoing or contained; if ongoing, escalate containment measures (e.g., network segmentation, system shutdown) | IT / Security Operations | Status update to Breach Coordinator |
| 2.3 | Activate backup systems and failover procedures to maintain business continuity where possible | IT Operations | Business continuity log |
| 2.4 | Preserve all forensic evidence before any remediation actions; create forensic images of affected systems | IT / Security Operations | Forensic imaging log; chain of custody |
| 2.5 | Notify Legal Counsel of the confirmed breach for immediate regulatory assessment | Breach Coordinator | Legal notification record |
| 2.6 | If third-party systems are involved, notify affected vendors per contractual obligations | Breach Coordinator / Legal | Vendor notification log |

### 5.3 Phase 3 — Investigation and Impact Assessment

**Timeline:** Within 24–72 hours

| Step | Action | Responsible Party | Documentation |
|------|--------|------------------|---------------|
| 3.1 | Conduct a thorough forensic investigation to determine: root cause, attack vector, scope of compromised data, affected individuals, and timeline of unauthorized access | IT / Security Operations (or external forensic firm) | Forensic Investigation Report |
| 3.2 | Identify all data types compromised (PHI, PII, financial data, credentials, etc.) and the exact volume of records affected | IT / Security Operations | Data Impact Assessment |
| 3.3 | Determine whether data was actually acquired/viewed or only exposed (access vs. exfiltration) | IT / Security Operations | Forensic findings addendum |
| 3.4 | Assess the risk of harm to affected individuals (identity theft, financial loss, discrimination, reputational harm) | Legal / Compliance | Risk of Harm Assessment |
| 3.5 | Legal Counsel determines all applicable notification requirements: federal, state, international, contractual, and industry-specific | Legal Counsel | Notification Obligation Matrix |
| 3.6 | Prepare the Breach Impact Summary for executive leadership | Breach Coordinator | Executive Briefing Document |

### 5.4 Phase 4 — Notification

**Timeline:** Per regulatory requirements (e.g., HIPAA: 60 days; GDPR: 72 hours; state laws vary)

| Step | Action | Responsible Party | Documentation |
|------|--------|------------------|---------------|
| 4.1 | Prepare individual notification letters for affected persons, including: description of breach, types of data involved, steps taken, protective measures recommended, contact information | Legal / Communications | Notification letter templates |
| 4.2 | Notify regulatory bodies as required (HHS/OCR for HIPAA, state AGs, FTC, supervisory authorities for GDPR) | Legal / Compliance | Regulatory notification filings |
| 4.3 | Notify law enforcement if criminal activity is suspected or if required by regulation | Legal | Law enforcement report |
| 4.4 | If >500 individuals affected (HIPAA) or as otherwise required, issue media notification | Communications / Legal | Media notice / press release |
| 4.5 | Offer credit monitoring or identity protection services where appropriate or required | Breach Coordinator | Service enrollment records |
| 4.6 | Notify business partners, clients, and contractual parties as required by agreements | Legal / Account Management | Partner notification log |
| 4.7 | Document all notifications sent: method, date, recipient, content | Breach Coordinator | Master Notification Log |

### 5.5 Phase 5 — Remediation and Recovery

**Timeline:** Within 30 days of containment

| Step | Action | Responsible Party | Documentation |
|------|--------|------------------|---------------|
| 5.1 | Implement permanent technical remediation: patch vulnerabilities, update configurations, enhance monitoring, reset all potentially compromised credentials | IT / Security Operations | Remediation action plan |
| 5.2 | Conduct a full security assessment of affected and adjacent systems | IT / Security Operations | Security assessment report |
| 5.3 | Update access controls, authentication mechanisms, and encryption as needed | IT / Security Operations | Configuration change log |
| 5.4 | Restore affected systems from clean backups after verification | IT Operations | Restoration log |
| 5.5 | Conduct targeted security awareness training for personnel involved | HR / Security | Training completion records |
| 5.6 | Review and update third-party risk assessments for involved vendors | Compliance | Updated vendor risk assessments |

### 5.6 Phase 6 — Post-Incident Review

**Timeline:** Within 45 days of incident closure

| Step | Action | Responsible Party | Documentation |
|------|--------|------------------|---------------|
| 6.1 | Conduct a formal post-incident review ("lessons learned") meeting with all Incident Response Team members | Breach Coordinator | Post-Incident Review Report |
| 6.2 | Identify root causes, control failures, and process gaps | All IRT Members | Root Cause Analysis |
| 6.3 | Develop and assign corrective actions with owners and deadlines | Breach Coordinator | Corrective Action Plan |
| 6.4 | Update this SOP and related policies based on findings | CISO / Compliance | Revision log |
| 6.5 | Update risk register to reflect new threat intelligence | Compliance / Security | Updated Risk Register |
| 6.6 | Archive the complete breach file (all documentation, evidence, correspondence) per record retention policy | Breach Coordinator | Archived case file reference |

## 6. Severity Classification Matrix

| Severity | Criteria | Response Time | Escalation Level |
|----------|----------|---------------|------------------|
| **Critical** | PHI/PII of >500 individuals; active exfiltration; ransomware deployment; systems of record compromised | Immediate (within 1 hour) | CISO + Executive Leadership + Legal + External Counsel |
| **High** | PHI/PII of <500 individuals; unauthorized access confirmed; sensitive financial data exposed | Within 2 hours | CISO + Legal + Compliance |
| **Medium** | Potential unauthorized access; no confirmed exfiltration; limited data scope | Within 4 hours | Security Operations + Breach Coordinator |
| **Low** | Suspicious activity; no confirmed unauthorized access; non-sensitive data | Within 24 hours | Security Operations |

## 7. Documentation Requirements

All breach response activities must be documented contemporaneously. The following records must be created and retained:

- [ ] Initial Incident Report Form
- [ ] Severity Classification and Triage Record
- [ ] Incident Response Team Activation Log
- [ ] Chain of Custody Forms for all evidence
- [ ] Forensic Investigation Report
- [ ] Data Impact Assessment
- [ ] Risk of Harm Assessment
- [ ] Notification Obligation Matrix
- [ ] All notification letters and filings (with proof of delivery)
- [ ] Master Notification Log
- [ ] Remediation Action Plan and completion records
- [ ] Post-Incident Review Report
- [ ] Corrective Action Plan with status tracking
- [ ] Executive Briefing Documents
- [ ] Complete case file archive

**Retention Period:** All breach-related documentation must be retained for a minimum of **6 years** (or longer if required by applicable regulation or ongoing litigation hold).

## 8. Key Performance Indicators

| Metric | Target |
|--------|--------|
| Mean Time to Detect (MTTD) | < 24 hours |
| Mean Time to Contain (MTTC) | < 4 hours from detection |
| Notification compliance rate | 100% within regulatory deadlines |
| Post-incident review completion | Within 45 days of closure |
| Corrective action closure rate | 100% within assigned deadlines |

## 9. Related Documents

- Incident Response Plan
- Information Security Policy
- Business Continuity Plan
- Vendor Management Policy
- Record Retention Policy
- SOP-04: Incident Reporting and Escalation

## 10. Review Schedule

| Review Activity | Frequency | Responsible Party |
|----------------|-----------|------------------|
| Full SOP review and update | Annually | CISO / Compliance Officer |
| Tabletop exercise / breach simulation | Semi-annually | Breach Coordinator / Security Operations |
| Contact list and escalation path verification | Quarterly | Breach Coordinator |
| Regulatory requirement update check | Quarterly | Legal / Compliance |
| Post-incident triggered review | After every breach or near-miss | Breach Coordinator |

## 11. Revision History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | _____________ | _____________ | Initial release |

## 12. Approval

| Role | Name | Signature | Date |
|------|------|-----------|------|
| CISO | | | |
| General Counsel | | | |
| Compliance Officer | | | |
| CEO / Executive Sponsor | | | |
