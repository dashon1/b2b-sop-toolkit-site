# Compliance Audit Log Template

**Document ID:** LOG-CAL-001  
**Version:** 1.0  
**Organization:** _______________  
**Compliance Officer:** _______________  
**Reporting Period:** _______________  
**Classification:** Confidential — Internal Use Only

---

## Instructions

This log serves as the central record for tracking all compliance activities, audits, findings, corrective actions, and regulatory interactions. Maintain this log continuously — it is a critical audit artifact demonstrating ongoing compliance program activity. Each section should be updated in real-time as events occur, not retrospectively.

---

## 1. Audit and Assessment Tracker

Track all internal and external audits, assessments, and examinations.

| Audit ID | Audit Type | Framework / Standard | Auditor / Firm | Scope / Departments | Start Date | End Date | Status | Total Findings | Critical | High | Medium | Low | Report Location |
|----------|-----------|---------------------|---------------|---------------------|-----------|---------|--------|---------------|----------|------|--------|-----|-----------------|
| AUD-001 | | | | | | | ☐ Planned ☐ In Progress ☐ Complete | | | | | | |
| AUD-002 | | | | | | | ☐ Planned ☐ In Progress ☐ Complete | | | | | | |
| AUD-003 | | | | | | | ☐ Planned ☐ In Progress ☐ Complete | | | | | | |
| AUD-004 | | | | | | | ☐ Planned ☐ In Progress ☐ Complete | | | | | | |
| AUD-005 | | | | | | | ☐ Planned ☐ In Progress ☐ Complete | | | | | | |
| AUD-006 | | | | | | | ☐ Planned ☐ In Progress ☐ Complete | | | | | | |
| AUD-007 | | | | | | | ☐ Planned ☐ In Progress ☐ Complete | | | | | | |
| AUD-008 | | | | | | | ☐ Planned ☐ In Progress ☐ Complete | | | | | | |

**Audit Types:** Internal Audit | External Audit (SOC 2) | Regulatory Examination | Client Audit | Self-Assessment | Mock Audit | Penetration Test | Vulnerability Assessment

---

## 2. Finding and Corrective Action Tracker

Track all findings from audits, assessments, incidents, and self-identified issues.

| Finding ID | Source Audit ID | Date Identified | Category | Severity | Finding Description | Root Cause | Corrective Action | Owner | Target Date | Completion Date | Status | Evidence of Remediation | Verified By | Verification Date |
|-----------|----------------|----------------|----------|----------|-------------------|-----------|-------------------|-------|------------|----------------|--------|------------------------|-------------|------------------|
| FND-001 | | | | ☐ Critical ☐ High ☐ Medium ☐ Low | | | | | | | ☐ Open ☐ In Progress ☐ Remediated ☐ Verified ☐ Closed | | | |
| FND-002 | | | | ☐ Critical ☐ High ☐ Medium ☐ Low | | | | | | | ☐ Open ☐ In Progress ☐ Remediated ☐ Verified ☐ Closed | | | |
| FND-003 | | | | ☐ Critical ☐ High ☐ Medium ☐ Low | | | | | | | ☐ Open ☐ In Progress ☐ Remediated ☐ Verified ☐ Closed | | | |
| FND-004 | | | | ☐ Critical ☐ High ☐ Medium ☐ Low | | | | | | | ☐ Open ☐ In Progress ☐ Remediated ☐ Verified ☐ Closed | | | |
| FND-005 | | | | ☐ Critical ☐ High ☐ Medium ☐ Low | | | | | | | ☐ Open ☐ In Progress ☐ Remediated ☐ Verified ☐ Closed | | | |
| FND-006 | | | | ☐ Critical ☐ High ☐ Medium ☐ Low | | | | | | | ☐ Open ☐ In Progress ☐ Remediated ☐ Verified ☐ Closed | | | |
| FND-007 | | | | ☐ Critical ☐ High ☐ Medium ☐ Low | | | | | | | ☐ Open ☐ In Progress ☐ Remediated ☐ Verified ☐ Closed | | | |
| FND-008 | | | | ☐ Critical ☐ High ☐ Medium ☐ Low | | | | | | | ☐ Open ☐ In Progress ☐ Remediated ☐ Verified ☐ Closed | | | |

**Categories:** Access Control | Data Protection | Incident Response | Vendor Management | Physical Security | Policy/Procedure | Training | Record Retention | Change Management | Business Continuity | Other

---

## 3. Policy and SOP Review Log

Track review and approval of all compliance-related policies and procedures.

| Document ID | Document Title | Owner | Current Version | Last Review Date | Next Review Date | Reviewer(s) | Status | Changes Made | Approval Date | Approved By |
|------------|---------------|-------|----------------|-----------------|-----------------|-------------|--------|-------------|--------------|-------------|
| | | | | | | | ☐ Current ☐ Under Review ☐ Overdue | | | |
| | | | | | | | ☐ Current ☐ Under Review ☐ Overdue | | | |
| | | | | | | | ☐ Current ☐ Under Review ☐ Overdue | | | |
| | | | | | | | ☐ Current ☐ Under Review ☐ Overdue | | | |
| | | | | | | | ☐ Current ☐ Under Review ☐ Overdue | | | |
| | | | | | | | ☐ Current ☐ Under Review ☐ Overdue | | | |
| | | | | | | | ☐ Current ☐ Under Review ☐ Overdue | | | |
| | | | | | | | ☐ Current ☐ Under Review ☐ Overdue | | | |

---

## 4. Training Compliance Tracker

Track mandatory compliance training completion across the organization.

| Training Module | Required For | Due Date | Total Enrolled | Completed | Incomplete | Completion Rate | Overdue Individuals | Follow-Up Action | Action Date |
|----------------|-------------|---------|---------------|-----------|-----------|----------------|--------------------|--------------------|------------|
| Security Awareness | All Personnel | | | | | ___% | | | |
| HIPAA Privacy & Security | PHI Access Roles | | | | | ___% | | | |
| SOC 2 Policies | Technology/Finance | | | | | ___% | | | |
| Incident Reporting | All Personnel | | | | | ___% | | | |
| Data Handling | All Personnel | | | | | ___% | | | |
| Ethics & Code of Conduct | All Personnel | | | | | ___% | | | |
| Anti-Harassment | All Personnel | | | | | ___% | | | |
| Role-Specific Training | Designated Roles | | | | | ___% | | | |

---

## 5. Incident and Breach Log

Track all security incidents, compliance events, and data breaches.

| Incident ID | Date Discovered | Date Reported | Category | Severity (P1–P4) | Description | Data Types Affected | # Records Affected | Containment Actions | Root Cause | Regulatory Notification Required? | Notification Date | Individuals Notified | Status | Closure Date | Lessons Learned Reference |
|------------|----------------|--------------|----------|------------------|-------------|--------------------|--------------------|--------------------|-----------|---------------------------------|-------------------|---------------------|--------|-------------|--------------------------|
| INC-001 | | | | | | | | | | ☐ Yes ☐ No | | | ☐ Open ☐ Contained ☐ Resolved ☐ Closed | | |
| INC-002 | | | | | | | | | | ☐ Yes ☐ No | | | ☐ Open ☐ Contained ☐ Resolved ☐ Closed | | |
| INC-003 | | | | | | | | | | ☐ Yes ☐ No | | | ☐ Open ☐ Contained ☐ Resolved ☐ Closed | | |
| INC-004 | | | | | | | | | | ☐ Yes ☐ No | | | ☐ Open ☐ Contained ☐ Resolved ☐ Closed | | |
| INC-005 | | | | | | | | | | ☐ Yes ☐ No | | | ☐ Open ☐ Contained ☐ Resolved ☐ Closed | | |

---

## 6. Vendor Compliance Tracker

Track third-party vendor compliance status.

| Vendor ID | Vendor Name | Risk Tier | Services Provided | Data Access Level | BAA/DPA in Place? | Last Assessment Date | Next Assessment Due | Assessment Score | Open Findings | SOC 2 Report Current? | Insurance Current? | Status |
|----------|-------------|-----------|-------------------|------------------|-------------------|---------------------|--------------------|-----------------|--------------|-----------------------|-------------------|--------|
| VEN-001 | | ☐ Critical ☐ High ☐ Medium ☐ Low | | | ☐ Yes ☐ No ☐ N/A | | | | | ☐ Yes ☐ No ☐ N/A | ☐ Yes ☐ No | ☐ Compliant ☐ Conditional ☐ Non-Compliant |
| VEN-002 | | ☐ Critical ☐ High ☐ Medium ☐ Low | | | ☐ Yes ☐ No ☐ N/A | | | | | ☐ Yes ☐ No ☐ N/A | ☐ Yes ☐ No | ☐ Compliant ☐ Conditional ☐ Non-Compliant |
| VEN-003 | | ☐ Critical ☐ High ☐ Medium ☐ Low | | | ☐ Yes ☐ No ☐ N/A | | | | | ☐ Yes ☐ No ☐ N/A | ☐ Yes ☐ No | ☐ Compliant ☐ Conditional ☐ Non-Compliant |
| VEN-004 | | ☐ Critical ☐ High ☐ Medium ☐ Low | | | ☐ Yes ☐ No ☐ N/A | | | | | ☐ Yes ☐ No ☐ N/A | ☐ Yes ☐ No | ☐ Compliant ☐ Conditional ☐ Non-Compliant |
| VEN-005 | | ☐ Critical ☐ High ☐ Medium ☐ Low | | | ☐ Yes ☐ No ☐ N/A | | | | | ☐ Yes ☐ No ☐ N/A | ☐ Yes ☐ No | ☐ Compliant ☐ Conditional ☐ Non-Compliant |

---

## 7. Risk Register Summary

Track identified risks and their treatment status.

| Risk ID | Risk Description | Risk Category | Likelihood (1–5) | Impact (1–5) | Risk Score | Risk Owner | Treatment Strategy | Treatment Actions | Target Date | Status | Last Review Date |
|---------|-----------------|--------------|------------------|--------------|------------|-----------|-------------------|------------------|------------|--------|-----------------|
| RSK-001 | | | | | | | ☐ Mitigate ☐ Transfer ☐ Accept ☐ Avoid | | | ☐ Open ☐ In Treatment ☐ Monitored ☐ Closed | |
| RSK-002 | | | | | | | ☐ Mitigate ☐ Transfer ☐ Accept ☐ Avoid | | | ☐ Open ☐ In Treatment ☐ Monitored ☐ Closed | |
| RSK-003 | | | | | | | ☐ Mitigate ☐ Transfer ☐ Accept ☐ Avoid | | | ☐ Open ☐ In Treatment ☐ Monitored ☐ Closed | |
| RSK-004 | | | | | | | ☐ Mitigate ☐ Transfer ☐ Accept ☐ Avoid | | | ☐ Open ☐ In Treatment ☐ Monitored ☐ Closed | |
| RSK-005 | | | | | | | ☐ Mitigate ☐ Transfer ☐ Accept ☐ Avoid | | | ☐ Open ☐ In Treatment ☐ Monitored ☐ Closed | |

---

## 8. Regulatory Interaction Log

Track all communications with regulatory bodies, auditors, and enforcement agencies.

| Date | Regulatory Body | Contact Method | Initiated By | Subject | Summary of Communication | Action Items | Follow-Up Required? | Follow-Up Date | Status |
|------|----------------|---------------|-------------|---------|-------------------------|-------------|---------------------|---------------|--------|
| | | ☐ Letter ☐ Email ☐ Phone ☐ On-site ☐ Portal | ☐ Regulator ☐ Organization | | | | ☐ Yes ☐ No | | ☐ Open ☐ Closed |
| | | ☐ Letter ☐ Email ☐ Phone ☐ On-site ☐ Portal | ☐ Regulator ☐ Organization | | | | ☐ Yes ☐ No | | ☐ Open ☐ Closed |
| | | ☐ Letter ☐ Email ☐ Phone ☐ On-site ☐ Portal | ☐ Regulator ☐ Organization | | | | ☐ Yes ☐ No | | ☐ Open ☐ Closed |

---

## 9. Access Review Certification Log

Track quarterly/periodic user access review completions.

| Review Period | System / Application | Reviewer (Manager) | Review Date | Total Accounts Reviewed | Accounts Confirmed | Accounts Flagged for Revocation | Revocations Completed Date | Certification Signed? |
|--------------|---------------------|-------------------|------------|------------------------|-------------------|---------------------------------|---------------------------|----------------------|
| | | | | | | | | ☐ Yes ☐ No |
| | | | | | | | | ☐ Yes ☐ No |
| | | | | | | | | ☐ Yes ☐ No |
| | | | | | | | | ☐ Yes ☐ No |
| | | | | | | | | ☐ Yes ☐ No |

---

## 10. Compliance Program KPI Dashboard

Update monthly or quarterly.

| Metric | Target | Q1 Actual | Q2 Actual | Q3 Actual | Q4 Actual | Annual | Trend |
|--------|--------|-----------|-----------|-----------|-----------|--------|-------|
| Policy review completion (on schedule) | 100% | | | | | | ☐ ↑ ☐ → ☐ ↓ |
| Training completion rate | 100% | | | | | | ☐ ↑ ☐ → ☐ ↓ |
| Open audit findings (total) | 0 | | | | | | ☐ ↑ ☐ → ☐ ↓ |
| Critical/High findings open >30 days | 0 | | | | | | ☐ ↑ ☐ → ☐ ↓ |
| Incident response time compliance | 100% | | | | | | ☐ ↑ ☐ → ☐ ↓ |
| Vendor assessment completion rate | 100% | | | | | | ☐ ↑ ☐ → ☐ ↓ |
| Access review completion rate | 100% | | | | | | ☐ ↑ ☐ → ☐ ↓ |
| Risk register items in treatment | <5 | | | | | | ☐ ↑ ☐ → ☐ ↓ |
| Regulatory inquiries / findings | 0 | | | | | | ☐ ↑ ☐ → ☐ ↓ |
| Days since last reportable breach | N/A | | | | | | ☐ ↑ ☐ → ☐ ↓ |

---

## Log Maintenance

| Activity | Frequency | Responsible Party |
|----------|-----------|------------------|
| Update all active sections | Continuously (as events occur) | Compliance Officer / Audit Coordinator |
| Full log review for accuracy and completeness | Monthly | Compliance Officer |
| KPI Dashboard update | Quarterly | Compliance Officer |
| Archive completed items | Quarterly | Records Coordinator |
| Retention | Minimum 7 years | Per organizational retention policy |

---

*This log is a compliance-critical document. Maintain accuracy, timeliness, and completeness at all times.*
