# QA Checklist: Employee Compliance Verification

**Document ID:** QA-EC-001  
**Version:** 1.0  
**Effective Date:** _______________  
**Classification:** Confidential — Internal Use Only

---

## Purpose

This 15-point checklist verifies that individual employees (and contractors) are in compliance with organizational security policies, regulatory training requirements, and operational procedures. Use this checklist during: new hire onboarding verification (30/60/90-day check), annual compliance reviews, pre-audit employee readiness assessments, and for-cause compliance investigations.

---

## Instructions

- Complete this checklist per employee or as a departmental roll-up
- Mark each item: **✅ Compliant** | **❌ Non-Compliant** | **⚠️ Partial** | **N/A Not Applicable**
- All **Non-Compliant** items require immediate corrective action
- Employees with 3+ Non-Compliant items must be escalated to HR and the Compliance Officer
- Retain completed checklists in the employee's compliance file

---

## Employee / Review Information

| Field | Value |
|-------|-------|
| **Employee Name** | |
| **Employee ID** | |
| **Department** | |
| **Job Title / Role** | |
| **Manager** | |
| **Employment Type** | ☐ Full-Time ☐ Part-Time ☐ Contractor ☐ Temporary ☐ Intern |
| **Start Date** | |
| **Review Type** | ☐ 30-Day Onboarding ☐ 60-Day Onboarding ☐ 90-Day Onboarding ☐ Annual Review ☐ Pre-Audit ☐ For-Cause ☐ Random Sampling |
| **Reviewer Name** | |
| **Review Date** | |

---

## Employee Compliance Verification Checklist

### Documentation and Agreements

| # | Verification Item | Status | Evidence / Notes | Corrective Action (if Non-Compliant) | Deadline |
|---|------------------|--------|-----------------|-------------------------------------|----------|
| 1 | **Background Check Completed:** A background check was completed before or within the required timeframe of the employee's start date. Results met organizational standards. Documentation is on file in HR. If the role requires periodic re-screening, the most recent check is within the required cycle. | ☐ Compliant ☐ Non-Compliant ☐ Partial ☐ N/A | | | |
| 2 | **Confidentiality / NDA Signed:** The employee has signed a current Confidentiality Agreement or Non-Disclosure Agreement. The signed copy is on file. For contract renewals, a new or renewed agreement is in effect. | ☐ Compliant ☐ Non-Compliant ☐ Partial ☐ N/A | | | |
| 3 | **Acceptable Use Policy Acknowledged:** The employee has signed an acknowledgment of the Acceptable Use Policy (covering IT systems, internet, email, and data handling). The acknowledgment is current (within the last 12 months or upon most recent policy revision). | ☐ Compliant ☐ Non-Compliant ☐ Partial ☐ N/A | | | |
| 4 | **Code of Conduct Acknowledged:** The employee has signed an acknowledgment of the organizational Code of Conduct and Ethics Policy within the last 12 months. | ☐ Compliant ☐ Non-Compliant ☐ Partial ☐ N/A | | | |

### Training and Competency

| # | Verification Item | Status | Evidence / Notes | Corrective Action (if Non-Compliant) | Deadline |
|---|------------------|--------|-----------------|-------------------------------------|----------|
| 5 | **Security Awareness Training Completed:** The employee has completed the required security awareness training within the mandated timeframe (upon hire + annually). Completion certificate or learning management system (LMS) record is on file. Training content is current (reflects the most recent training cycle). | ☐ Compliant ☐ Non-Compliant ☐ Partial ☐ N/A | | | |
| 6 | **Regulatory-Specific Training Completed:** If the employee's role requires industry-specific training (HIPAA for PHI access, SOC 2 policies for technology roles, legal ethics for legal staff), the required training has been completed within the mandated timeframe. Completion records are on file. | ☐ Compliant ☐ Non-Compliant ☐ Partial ☐ N/A | | | |
| 7 | **Incident Reporting Awareness:** The employee can identify the correct channels for reporting security incidents and compliance concerns (Incident Hotline, secure email, portal, or supervisor). Verified through training records or brief interview. The employee understands the requirement to report within 1 hour of discovery. | ☐ Compliant ☐ Non-Compliant ☐ Partial ☐ N/A | | | |

### Access and Credentials

| # | Verification Item | Status | Evidence / Notes | Corrective Action (if Non-Compliant) | Deadline |
|---|------------------|--------|-----------------|-------------------------------------|----------|
| 8 | **Access Appropriate for Role:** The employee's current system and application access has been reviewed against their role requirements. Access is consistent with the principle of least privilege. No excessive, unnecessary, or orphaned access exists. Access was verified during the most recent periodic access review. | ☐ Compliant ☐ Non-Compliant ☐ Partial ☐ N/A | | | |
| 9 | **Multi-Factor Authentication (MFA) Active:** MFA is enrolled and active for all required accounts (email, VPN, cloud services, systems containing sensitive data). No MFA exemptions exist without documented risk acceptance from the CISO. MFA method meets organizational standards (authenticator app or hardware token preferred; SMS may be restricted). | ☐ Compliant ☐ Non-Compliant ☐ Partial ☐ N/A | | | |
| 10 | **Password Policy Compliance:** The employee's accounts comply with the password policy: minimum length, complexity requirements, and rotation schedule (where applicable). No shared passwords or credentials. No passwords stored in insecure locations (sticky notes, plaintext files, shared documents). | ☐ Compliant ☐ Non-Compliant ☐ Partial ☐ N/A | | | |

### Data Handling and Physical Security

| # | Verification Item | Status | Evidence / Notes | Corrective Action (if Non-Compliant) | Deadline |
|---|------------------|--------|-----------------|-------------------------------------|----------|
| 11 | **Clean Desk Compliance:** The employee's workspace complies with the clean desk policy: no sensitive documents left unattended; screens locked when away from desk; sensitive papers in locked storage when not in active use; no confidential information visible to unauthorized persons. (Verify by observation or desk audit.) | ☐ Compliant ☐ Non-Compliant ☐ Partial ☐ N/A | | | |
| 12 | **Device Security:** The employee's devices (laptop, phone, tablet) comply with security requirements: full-disk encryption enabled; screen lock active (auto-lock ≤ 15 minutes); antivirus/endpoint protection installed and current; operating system and applications patched and up-to-date; no unauthorized software installed. For personal devices (BYOD): MDM enrolled if required; organizational data is containerized. | ☐ Compliant ☐ Non-Compliant ☐ Partial ☐ N/A | | | |
| 13 | **Physical Access Credentials Valid:** The employee's badge/access card is valid and functional. Badge photo matches the employee. Badge permissions correspond to their current role and authorized areas. No temporary or loaner badge in use beyond the permitted timeframe. Lost/stolen badges have been reported and deactivated. | ☐ Compliant ☐ Non-Compliant ☐ Partial ☐ N/A | | | |

### Behavioral and Operational Compliance

| # | Verification Item | Status | Evidence / Notes | Corrective Action (if Non-Compliant) | Deadline |
|---|------------------|--------|-----------------|-------------------------------------|----------|
| 14 | **No Outstanding Compliance Violations:** The employee has no outstanding, unresolved compliance violations or sanctions. If prior violations exist, corrective actions have been completed and documented. No pattern of repeated minor violations exists. HR and Compliance records are clean or appropriately resolved. | ☐ Compliant ☐ Non-Compliant ☐ Partial ☐ N/A | | | |
| 15 | **Regulatory Obligations Understood:** The employee demonstrates understanding of their specific regulatory obligations based on their role: handling of PHI (if applicable); client confidentiality (if applicable); financial data protection (if applicable); mandatory reporting obligations; consequences of non-compliance. Verified through training records, acknowledgment forms, or brief interview. | ☐ Compliant ☐ Non-Compliant ☐ Partial ☐ N/A | | | |

---

## Review Summary

| Category | Compliant | Non-Compliant | Partial | N/A |
|----------|-----------|--------------|---------|-----|
| Documentation & Agreements (1–4) | | | | |
| Training & Competency (5–7) | | | | |
| Access & Credentials (8–10) | | | | |
| Data Handling & Physical (11–13) | | | | |
| Behavioral & Operational (14–15) | | | | |
| **TOTAL** | **___/15** | **___/15** | **___/15** | **___/15** |

---

## Overall Compliance Status

| Status | Criteria |
|--------|---------|
| ☐ **Fully Compliant** | All items Compliant or N/A |
| ☐ **Conditionally Compliant** | 1–2 Partial items with corrective actions due within 14 days; no Non-Compliant items |
| ☐ **Non-Compliant** | 1+ Non-Compliant items; corrective actions assigned; escalation to Compliance Officer |
| ☐ **Critical Non-Compliance** | 3+ Non-Compliant items; escalation to HR Director and Compliance Officer; may result in access suspension pending remediation |

---

## Corrective Action Summary

| Item # | Issue | Corrective Action | Owner | Deadline | Completion Date | Verified By |
|--------|-------|-------------------|-------|----------|----------------|-------------|
| | | | | | | |
| | | | | | | |
| | | | | | | |

---

## Sign-Off

| Role | Name | Signature | Date |
|------|------|-----------|------|
| Reviewer | | | |
| Employee (acknowledgment) | | | |
| Department Manager | | | |
| Compliance Officer (if escalated) | | | |

---

*Retain this completed checklist in the employee's compliance file for a minimum of 7 years after employment or engagement ends.*
