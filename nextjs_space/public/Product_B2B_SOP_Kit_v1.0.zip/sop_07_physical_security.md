# SOP-07: Physical Security

**Document ID:** SOP-07-PSC  
**Version:** 1.0  
**Effective Date:** _______________  
**Last Reviewed:** _______________  
**Document Owner:** Director of Facilities / Physical Security Manager  
**Classification:** Confidential — Internal Use Only

---

## 1. Purpose

This Standard Operating Procedure establishes the physical security controls required to protect organizational personnel, facilities, equipment, and information assets from unauthorized physical access, theft, damage, and environmental threats. Physical security is a foundational control required by HIPAA (§164.310 — Physical Safeguards), SOC 2 (CC6.4 — Physical Access), PCI DSS, and other regulatory frameworks.

## 2. Scope

This SOP applies to:

- All organizational facilities: corporate offices, data centers, satellite offices, storage facilities, and remote work locations where organizational data is processed
- All physical access points: doors, loading docks, server rooms, network closets, file storage rooms, and restricted areas
- All personnel: employees, contractors, visitors, vendors, maintenance workers, and cleaning staff
- All physical assets: servers, network equipment, workstations, mobile devices, storage media, and paper records

## 3. Definitions

| Term | Definition |
|------|-----------|
| **Restricted Area** | Any space that requires additional authorization beyond general facility access (e.g., data center, server room, records storage, executive areas) |
| **Access Badge** | A proximity card, smart card, or key fob that grants physical access to organizational facilities and areas |
| **Mantrap** | A two-door access control vestibule that prevents unauthorized entry by requiring authentication at both doors |
| **Tailgating** | The act of an unauthorized person following an authorized person through a secured access point |
| **Visitor** | Any person who is not a current employee or authorized contractor requiring access to organizational facilities |
| **Environmental Controls** | Systems designed to protect physical assets from environmental threats: HVAC, fire suppression, flood detection, and power management |

## 4. Responsibilities

| Role | Responsibilities |
|------|-----------------|
| **Facilities Director / Physical Security Manager** | Owns this SOP; manages physical security program; oversees access control systems |
| **Security Guards / Reception** | Monitor access points; verify visitor identity; respond to alarms; patrol facilities |
| **IT Operations** | Manages data center physical security; coordinates on hardware installation/removal |
| **HR** | Coordinates badge issuance for new hires and collection at offboarding |
| **Department Managers** | Authorize visitor access to their areas; report physical security concerns |
| **Compliance Officer** | Audits physical security controls for regulatory compliance |
| **All Personnel** | Comply with physical security policies; report security incidents; do not allow tailgating |

## 5. Procedures

### 5.1 Facility Access Control

| Step | Action | Responsible Party | Documentation |
|------|--------|------------------|---------------|
| 1.1 | All facility entry/exit points must be secured with electronic access control (badge reader or biometric) and monitored by CCTV | Facilities | Access control system configuration; CCTV placement map |
| 1.2 | Employees receive an access badge upon onboarding (per SOP-03) encoded with permissions based on their role and department | Facilities / HR | Badge issuance log |
| 1.3 | Badge access permissions are assigned based on the Physical Access Matrix, which maps roles to authorized areas | Facilities | Physical Access Matrix (current version) |
| 1.4 | All badge access events (entry and exit) are logged electronically and retained for a minimum of 90 days | Facilities | Electronic access logs |
| 1.5 | Doors to restricted areas must auto-lock and must not be propped open; alarms alert if a restricted-area door is held open > 30 seconds | Facilities | Door alarm configuration |
| 1.6 | Lost or stolen badges must be reported within 4 hours; reported badges are immediately deactivated and a replacement is issued | Employee / Facilities | Lost badge report; deactivation log |

### 5.2 Restricted Area Controls

| Area Type | Required Controls |
|-----------|------------------|
| **Data Center / Server Room** | Badge + biometric (or PIN) dual authentication; mantrap or airlock entry; CCTV with 90-day recording retention; environmental monitoring (temperature, humidity, water detection); visitor escort required at all times; entry/exit log |
| **Network / Telecom Closets** | Badge access restricted to IT staff; locked when unattended; access log maintained; no storage of non-IT materials |
| **Records Storage Room** | Badge access restricted to authorized records personnel; locked when unattended; environmental controls (fire suppression, climate control); inventory log maintained |
| **Executive / Sensitive Areas** | Badge access restricted to authorized personnel; visitor escort required; CCTV at entry points |
| **Loading Dock / Shipping** | Controlled access; separation from main office areas; CCTV monitoring; deliveries logged and inspected |

### 5.3 Visitor Management

| Step | Action | Responsible Party | Documentation |
|------|--------|------------------|---------------|
| 3.1 | All visitors must be pre-registered by their organizational sponsor (Department Manager or authorized employee) | Sponsor | Visitor pre-registration form |
| 3.2 | Upon arrival, visitors check in at reception and present government-issued photo identification | Reception / Security | Visitor log entry; ID verification |
| 3.3 | Visitors sign a Visitor Agreement acknowledging security and confidentiality requirements | Visitor | Signed Visitor Agreement |
| 3.4 | Visitors receive a clearly identifiable temporary visitor badge that displays name, date, and escort requirement | Reception | Visitor badge issued |
| 3.5 | Visitors must be escorted by their sponsor at all times in the facility; unescorted visitors in restricted areas trigger a security response | Sponsor | N/A |
| 3.6 | Visitors are not permitted to: use organizational computers or networks, photograph restricted areas, remove any organizational materials, or access restricted areas without specific authorization | Visitor / Sponsor | Visitor Agreement terms |
| 3.7 | Upon departure, visitors return their temporary badge and sign out at reception | Reception | Visitor log exit entry |
| 3.8 | Visitor logs are retained for a minimum of 1 year | Facilities | Archived visitor logs |

### 5.4 CCTV and Surveillance

| Requirement | Standard |
|-------------|----------|
| **Coverage** | All building entry/exit points, parking areas, loading docks, data center entry, restricted area entry, reception area, hallways leading to restricted areas |
| **Recording** | Continuous recording, 24/7; minimum resolution of 1080p |
| **Retention** | Minimum 90 days for general footage; 1 year for restricted area footage; indefinite retention for incident-related footage |
| **Monitoring** | Real-time monitoring during business hours by security personnel; motion-detection alerts after hours |
| **Access to Footage** | Restricted to Physical Security Manager, CISO, Legal Counsel, and authorized investigators |
| **Signage** | "Premises Under Video Surveillance" signage posted at all monitored areas as required by law |
| **Maintenance** | Monthly camera functionality check; quarterly review of coverage adequacy |

### 5.5 Environmental and Safety Controls

| Control | Standard | Monitoring |
|---------|----------|-----------|
| **Fire Detection** | Smoke and heat detectors in all occupied spaces and data centers; connected to building fire alarm and local fire department | Continuous automated; tested semi-annually |
| **Fire Suppression** | Sprinkler systems in office areas; clean agent (FM-200 or equivalent) in data center and records storage | Annual inspection by certified contractor |
| **HVAC / Climate** | Data center maintained at 64–75°F (18–24°C), 40–60% relative humidity | Continuous automated monitoring with alerts |
| **Water Detection** | Water sensors under raised floors, near pipes, and in basement areas | Continuous automated with alerts |
| **Power** | Uninterruptible Power Supply (UPS) for critical systems; backup generator with automatic transfer switch; minimum 72-hour fuel supply | Monthly generator test; quarterly full-load test |
| **Emergency Lighting** | Battery-backed emergency lighting in all occupied areas and exit routes | Monthly test; annual full-duration test |

### 5.6 Asset Protection

| Step | Action | Responsible Party | Documentation |
|------|--------|------------------|---------------|
| 6.1 | All IT hardware must be inventoried in the Asset Management System with unique identifiers (asset tags) | IT Operations | Asset inventory |
| 6.2 | Removal of any IT equipment from the facility requires an authorized Equipment Removal Form signed by the Department Manager and IT | Department Manager / IT | Equipment Removal Form |
| 6.3 | Decommissioned hardware must follow secure disposal procedures per SOP-05 before leaving the facility | IT / Facilities | Disposal/destruction records |
| 6.4 | Portable devices (laptops, tablets, phones) must use cable locks or be stored in locked drawers when unattended in the office | All personnel | N/A |
| 6.5 | Sensitive paper documents must be secured in locked cabinets when not in active use; clean desk policy is enforced | All personnel | Clean desk audit results |
| 6.6 | Delivery and removal of large equipment must be logged, photographed, and verified against purchase or disposal orders | Facilities / IT | Delivery/removal log |

### 5.7 Incident Response — Physical Security Events

| Incident Type | Immediate Action | Notification |
|--------------|-----------------|-------------|
| **Unauthorized access detected** | Security responds; identify and confront/escort the individual; review CCTV; determine if data/assets were accessed | Physical Security Manager → CISO (if data involved) |
| **Badge theft or loss** | Immediately deactivate the badge; issue replacement; review access logs for unauthorized use | Facilities → IT Security |
| **Tailgating detected** | Stop the unauthorized individual; report the incident; reinforce anti-tailgating awareness | All personnel → Security |
| **Environmental alarm** | Follow emergency procedures; evacuate if necessary; notify Facilities for investigation | Facilities → Building Management → Emergency Services if needed |
| **Theft or vandalism** | Secure the scene; do not disturb evidence; contact Security and law enforcement as appropriate | Security → CISO → Legal → Law Enforcement |

## 6. Documentation Requirements

- [ ] Physical Access Matrix (role-to-area mapping)
- [ ] Badge issuance, deactivation, and return logs
- [ ] Electronic access control logs (90-day minimum retention)
- [ ] Visitor logs and signed Visitor Agreements (1-year retention)
- [ ] CCTV recording inventory and retention schedule
- [ ] Environmental monitoring logs and alarm records
- [ ] Equipment removal forms
- [ ] Asset inventory (current)
- [ ] Clean desk audit results
- [ ] Fire suppression and safety inspection reports
- [ ] Generator and UPS test logs
- [ ] Physical security incident reports

**Retention Period:** Physical security records must be retained for a minimum of **3 years** (or longer per regulatory or contractual requirements).

## 7. Key Performance Indicators

| Metric | Target |
|--------|--------|
| CCTV system uptime | > 99.5% |
| Badge access audit completion (quarterly) | 100% |
| Visitor escort compliance | 100% |
| Environmental alarm response time | < 5 minutes |
| Lost/stolen badge deactivation time | < 4 hours from report |
| Clean desk policy compliance (quarterly audit) | > 95% |

## 8. Related Documents

- SOP-02: Access Control and Authentication
- SOP-03: Employee Onboarding and Offboarding
- SOP-05: Record Retention and Disposal
- Information Security Policy
- Business Continuity Plan
- Emergency Action Plan

## 9. Review Schedule

| Review Activity | Frequency | Responsible Party |
|----------------|-----------|------------------|
| Full SOP review and update | Annually | Facilities Director / CISO |
| Physical Access Matrix review | Semi-annually | Facilities / HR / IT Security |
| CCTV coverage assessment | Quarterly | Physical Security Manager |
| Environmental controls inspection | Semi-annually | Facilities / Certified Contractors |
| Physical security walkthrough | Monthly | Physical Security Manager |

## 10. Revision History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | _____________ | _____________ | Initial release |

## 11. Approval

| Role | Name | Signature | Date |
|------|------|-----------|------|
| Facilities Director | | | |
| CISO | | | |
| Compliance Officer | | | |
| COO | | | |
