# SOP-03: Employee Onboarding and Offboarding

**Document ID:** SOP-03-EOO  
**Version:** 1.0  
**Effective Date:** _______________  
**Last Reviewed:** _______________  
**Document Owner:** Director of Human Resources  
**Classification:** Confidential — Internal Use Only

---

## 1. Purpose

This Standard Operating Procedure defines the end-to-end processes for securely onboarding new personnel and offboarding departing personnel to ensure regulatory compliance, protect organizational data assets, and maintain a complete audit trail. It addresses the unique requirements of regulated industries where improper access provisioning or deprovisioning creates significant compliance and security risk.

## 2. Scope

This SOP applies to:

- All new hires (full-time, part-time), contractors, temporary staff, interns, and third-party consultants
- All departures: voluntary resignations, involuntary terminations, retirements, contract expirations, and transfers to other entities
- All departments and business units across all organizational locations
- Both logical (system/application) and physical (facility/equipment) access

## 3. Definitions

| Term | Definition |
|------|-----------|
| **Onboarding** | The process of integrating a new employee or contractor into the organization, including access provisioning, training, and compliance acknowledgments |
| **Offboarding** | The process of securely separating a departing employee or contractor from the organization, including access revocation and asset recovery |
| **Background Check** | Pre-employment screening including criminal history, employment verification, education verification, and where permitted, credit check |
| **Compliance Training** | Mandatory training on organizational policies, regulatory requirements, and security awareness |
| **Exit Interview** | A structured conversation with a departing employee to gather feedback and reinforce ongoing obligations |

## 4. Responsibilities

| Role | Responsibilities |
|------|-----------------|
| **HR Director** | Owns this SOP; oversees onboarding and offboarding programs; ensures compliance training completion |
| **HR Coordinators** | Execute onboarding/offboarding checklists; collect required documentation; schedule training |
| **Hiring Manager** | Submits access requests; assigns a mentor/buddy; confirms role-specific training requirements |
| **IT / IAM Team** | Provisions and deprovisions system access; configures equipment; manages credential lifecycle |
| **Compliance Officer** | Verifies compliance training is current; ensures regulatory acknowledgments are collected and filed |
| **Facilities / Physical Security** | Issues and collects physical access credentials; manages workspace assignment and clearing |
| **Legal Counsel** | Reviews employment agreements; manages NDA execution; conducts legal portions of exit process |
| **Department Manager** | Certifies completion of role-specific onboarding; initiates offboarding requests |

## 5. Procedures

### 5.1 Pre-Boarding (Before Day 1)

| Step | Action | Responsible Party | Timeline | Documentation |
|------|--------|------------------|----------|---------------|
| 1.1 | Initiate background check upon acceptance of offer | HR Coordinator | Upon offer acceptance | Background check authorization form; results report |
| 1.2 | Verify background check results meet organizational standards; escalate exceptions to HR Director | HR Coordinator | Before start date | Background check clearance |
| 1.3 | Prepare and send employment agreement, NDA, and confidentiality agreement for signature | HR / Legal | 5+ days before start | Signed agreements |
| 1.4 | Submit New User Access Request based on role template to IAM Team (per SOP-02) | Hiring Manager | 5+ days before start | Approved Access Request Form |
| 1.5 | Provision workstation, equipment, and software per role requirements | IT Operations | 2+ days before start | Equipment assignment form |
| 1.6 | Create user accounts and configure access per approved request | IAM Team | 1+ day before start | Provisioning log |
| 1.7 | Prepare physical access credentials (badge, keys, parking) | Facilities | 1+ day before start | Badge issuance record |
| 1.8 | Assign workspace, schedule orientation sessions, and notify the onboarding team | HR Coordinator | 2+ days before start | Onboarding schedule |

### 5.2 Day 1 — Orientation and Initial Setup

| Step | Action | Responsible Party | Documentation |
|------|--------|------------------|---------------|
| 2.1 | Welcome and verify identity (government-issued photo ID, I-9 documentation) | HR Coordinator | I-9 form; ID verification record |
| 2.2 | Issue physical access badge and provide facility tour including emergency exits, restricted areas, and security protocols | Facilities / HR | Badge receipt acknowledgment |
| 2.3 | Distribute IT equipment and credentials; assist with initial login and MFA enrollment | IT / IAM | Equipment receipt form; MFA enrollment confirmation |
| 2.4 | Review and obtain signed acknowledgment of Employee Handbook, Code of Conduct, and Acceptable Use Policy | HR Coordinator | Signed acknowledgment forms |
| 2.5 | Enroll in mandatory compliance training modules (see Section 5.3) | HR Coordinator | Training enrollment record |
| 2.6 | Introduce to direct manager, team members, and assigned mentor/buddy | Hiring Manager | N/A |
| 2.7 | Review job description, performance expectations, and probation/review timeline | Hiring Manager | Signed job description |

### 5.3 Compliance Training Requirements

All new personnel must complete the following within **30 days** of start date:

| Training Module | Applicability | Completion Deadline |
|----------------|--------------|-------------------|
| Security Awareness Training | All personnel | Day 14 |
| HIPAA Privacy and Security (if handling PHI) | Healthcare / PHI access | Day 14 |
| SOC 2 Security Policies (if applicable) | Finance / Technology | Day 14 |
| Anti-Harassment and Discrimination | All personnel | Day 30 |
| Data Classification and Handling | All personnel | Day 14 |
| Incident Reporting Procedures | All personnel | Day 7 |
| Role-Specific Regulatory Training | As determined by Compliance | Day 30 |
| Business Continuity / Emergency Procedures | All personnel | Day 30 |

**Important:** Access to systems containing PHI, PII, or financial data must NOT be activated until the corresponding training module is completed and documented.

### 5.4 Onboarding Completion Verification

| Step | Action | Responsible Party | Timeline | Documentation |
|------|--------|------------------|----------|---------------|
| 4.1 | Verify all compliance training modules are completed | HR Coordinator / Compliance | Day 30 | Training completion certificates |
| 4.2 | Confirm all required documents are signed and filed (agreements, acknowledgments, policies) | HR Coordinator | Day 14 | Document checklist (complete) |
| 4.3 | Hiring Manager certifies the employee has received adequate role-specific orientation | Hiring Manager | Day 30 | Manager certification form |
| 4.4 | Close onboarding file and archive in HR records system | HR Coordinator | Day 30 | Archived onboarding file |

### 5.5 Offboarding — Voluntary Departure

| Step | Action | Responsible Party | Timeline | Documentation |
|------|--------|------------------|----------|---------------|
| 5.1 | Employee submits written resignation; Manager acknowledges and notifies HR | Employee / Manager | Upon resignation | Resignation letter; acknowledgment |
| 5.2 | HR initiates the Offboarding Checklist and notifies all relevant departments (IT, Facilities, Compliance, Legal, Finance) | HR Coordinator | Within 1 business day | Offboarding Checklist initiated |
| 5.3 | Schedule exit interview | HR Coordinator | Before last day | Exit interview schedule |
| 5.4 | Manager identifies knowledge transfer requirements and assigns transition tasks | Department Manager | During notice period | Knowledge transfer plan |
| 5.5 | Conduct exit interview covering: feedback, ongoing obligations (NDA, non-compete), return of property, benefits information | HR Coordinator | Last day or day before | Signed Exit Interview Form |
| 5.6 | Remind departing employee of continuing confidentiality, non-disclosure, and non-solicitation obligations in writing | Legal / HR | Last day | Signed obligations reminder |
| 5.7 | Collect all organizational assets: laptop, phone, badge, keys, tokens, parking pass, credit cards, paper files | IT / Facilities / HR | Last day | Asset return checklist (signed) |
| 5.8 | Disable all logical access by end of business on last day (per SOP-02, Section 5.4) | IAM Team | Last day, by EOB | Deprovisioning log |
| 5.9 | Revoke physical access (deactivate badge, change shared codes if applicable) | Facilities | Last day, by EOB | Physical access revocation log |
| 5.10 | Verify complete offboarding across all systems and facilities | IT Security / HR | Within 24 hours of last day | Offboarding Verification Report |

### 5.6 Offboarding — Involuntary Termination

| Step | Action | Responsible Party | Timeline | Documentation |
|------|--------|------------------|----------|---------------|
| 6.1 | HR and Legal approve the termination decision and prepare documentation | HR Director / Legal | Before termination meeting | Termination approval; supporting documentation |
| 6.2 | HR notifies IT Security and IAM to prepare for immediate access revocation (standby) | HR Coordinator | Before termination meeting | Standby notification |
| 6.3 | Conduct the termination meeting with HR and Manager present | HR / Manager | Scheduled time | Meeting notes |
| 6.4 | **Simultaneously** with or immediately following the meeting: IAM disables all logical access (accounts, VPN, SSO, email, cloud services) | IAM Team | During/immediately after meeting | Emergency deprovisioning log |
| 6.5 | Collect all organizational assets immediately | HR / Facilities | During meeting | Asset return checklist |
| 6.6 | Revoke physical access credentials and escort the individual from the premises | Facilities / Security | Immediately | Physical access revocation log; escort log |
| 6.7 | Initiate remote wipe on any company-managed personal devices | IT Operations | Within 1 hour | Device wipe confirmation |
| 6.8 | Review the terminated employee's recent data access and transfer activity for anomalies | IT Security | Within 24 hours | Data access audit report |
| 6.9 | Verify complete offboarding across all systems | IT Security | Within 24 hours | Offboarding Verification Report |

### 5.7 Contractor and Temporary Staff Procedures

- Contractors must follow the same onboarding and offboarding processes with the following additional requirements:
  - Access is automatically set to expire on the contract end date
  - Contract renewal requires a new Access Request and Manager re-approval
  - Quarterly review of all active contractor access by the Compliance Officer
  - Contractors must not be granted privileged access without CISO approval

## 6. Documentation Requirements

- [ ] Background Check Authorization and Results
- [ ] Signed Employment Agreement / Contractor Agreement
- [ ] Signed NDA and Confidentiality Agreement
- [ ] I-9 Employment Eligibility Verification
- [ ] Equipment and Asset Issuance/Return Records
- [ ] Compliance Training Completion Certificates
- [ ] Signed Policy Acknowledgment Forms
- [ ] Access Request and Provisioning Records
- [ ] Onboarding Completion Certification
- [ ] Exit Interview Form (signed)
- [ ] Continuing Obligations Reminder (signed)
- [ ] Offboarding Checklist (completed and signed)
- [ ] Deprovisioning Verification Report
- [ ] Asset Return Checklist (signed)

**Retention Period:** All onboarding and offboarding records must be retained for a minimum of **7 years** after the last date of employment or engagement.

## 7. Key Performance Indicators

| Metric | Target |
|--------|--------|
| Pre-boarding checklist completion before Day 1 | 100% |
| Compliance training completion within 30 days | 100% |
| Voluntary offboarding access revocation by EOB on last day | 100% |
| Involuntary offboarding access revocation within 1 hour | 100% |
| Asset recovery rate at offboarding | 100% |
| Offboarding verification within 24 hours | 100% |

## 8. Related Documents

- SOP-02: Access Control and Authentication
- SOP-07: Physical Security
- Employee Handbook
- Acceptable Use Policy
- NDA Template
- Background Check Policy

## 9. Review Schedule

| Review Activity | Frequency | Responsible Party |
|----------------|-----------|------------------|
| Full SOP review and update | Annually | HR Director / Compliance Officer |
| Onboarding checklist and training content review | Semi-annually | HR / Compliance |
| Offboarding process audit (sample review) | Quarterly | IT Security / Compliance |
| Regulatory training requirement update | Annually or upon regulatory change | Compliance Officer |

## 10. Revision History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | _____________ | _____________ | Initial release |

## 11. Approval

| Role | Name | Signature | Date |
|------|------|-----------|------|
| HR Director | | | |
| CISO | | | |
| Compliance Officer | | | |
| Legal Counsel | | | |
