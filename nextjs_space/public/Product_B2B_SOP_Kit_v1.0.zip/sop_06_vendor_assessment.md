# SOP-06: Vendor Risk Assessment and Management

**Document ID:** SOP-06-VRA  
**Version:** 1.0  
**Effective Date:** _______________  
**Last Reviewed:** _______________  
**Document Owner:** Compliance Officer / Procurement Director  
**Classification:** Confidential — Internal Use Only

---

## 1. Purpose

This Standard Operating Procedure establishes a systematic process for assessing, selecting, monitoring, and managing third-party vendors to ensure they meet the organization's security, privacy, compliance, and operational standards. In regulated industries, vendor risk management is not optional — regulatory frameworks (HIPAA Business Associate requirements, SOC 2 vendor management criteria, GLBA service provider oversight) impose direct liability for vendor actions affecting protected data and regulated processes.

## 2. Scope

This SOP applies to:

- All third-party vendors, suppliers, service providers, contractors, and business partners who: access, process, store, or transmit organizational data; provide technology services (SaaS, IaaS, PaaS, managed services); perform functions on behalf of the organization that involve regulated data; have physical or logical access to organizational systems or facilities
- All stages of the vendor lifecycle: selection, onboarding, ongoing monitoring, and termination
- All departments that engage or manage vendor relationships

## 3. Definitions

| Term | Definition |
|------|-----------|
| **Vendor** | Any third-party entity that provides goods, services, or technology to the organization |
| **Business Associate** | A vendor that creates, receives, maintains, or transmits PHI on behalf of a covered entity (HIPAA) |
| **Sub-processor** | A third party engaged by a vendor to process data on the organization's behalf |
| **Due Diligence** | The process of evaluating a vendor's capabilities, security posture, and compliance status before engagement |
| **Vendor Risk Tier** | A classification (Critical, High, Medium, Low) based on the vendor's access to data, systems, and operational criticality |
| **BAA** | Business Associate Agreement — required by HIPAA when a vendor handles PHI |

## 4. Responsibilities

| Role | Responsibilities |
|------|-----------------|
| **Compliance Officer** | Owns this SOP; oversees the vendor risk management program; approves vendor risk assessments |
| **Procurement** | Manages vendor contracts; coordinates with Legal on agreement terms; maintains vendor registry |
| **IT Security** | Conducts technical security assessments; reviews vendor security documentation; monitors vendor security posture |
| **Legal Counsel** | Reviews and negotiates vendor contracts, BAAs, data processing agreements, and liability terms |
| **Business Owner / Requesting Department** | Initiates vendor requests; defines business requirements; serves as the primary vendor relationship manager |
| **Privacy Officer** | Evaluates data privacy implications; ensures data processing agreements are in place |
| **Finance** | Evaluates vendor financial stability; manages payment terms and budgeting |

## 5. Procedures

### 5.1 Vendor Risk Tiering

Before any assessment begins, classify the vendor based on the following criteria:

| Risk Tier | Criteria | Assessment Requirements |
|-----------|---------|----------------------|
| **Critical** | Vendor accesses, processes, or stores PHI, PII, or financial data for >500 records; provides infrastructure or core business applications; single point of failure | Full due diligence; on-site or virtual audit; annual reassessment; continuous monitoring; executive approval |
| **High** | Vendor accesses confidential data; provides significant IT services; handles regulated data for <500 records; has network connectivity to organizational systems | Full due diligence; detailed security questionnaire; annual reassessment; periodic monitoring |
| **Medium** | Vendor accesses internal (non-regulated) data; provides professional services with limited system access; has physical access to facilities | Standard due diligence; security questionnaire; biennial reassessment |
| **Low** | Vendor provides commodity goods or services; no access to organizational data, systems, or facilities | Basic due diligence; standard contract terms; reassessment at renewal |

### 5.2 Pre-Engagement Due Diligence

| Step | Action | Responsible Party | Documentation |
|------|--------|------------------|---------------|
| 2.1 | Business Owner submits a Vendor Engagement Request identifying the vendor, services required, data types involved, and business justification | Business Owner | Vendor Engagement Request Form |
| 2.2 | Compliance assigns the vendor risk tier based on the criteria in Section 5.1 | Compliance Officer | Risk tier assignment |
| 2.3 | For Critical and High vendors, distribute the Vendor Security Questionnaire (based on SIG/SIG Lite or equivalent) | IT Security | Completed questionnaire |
| 2.4 | Request and review the vendor's security certifications: SOC 2 Type II report, ISO 27001 certificate, HITRUST certification, penetration test results | IT Security | Certification review notes |
| 2.5 | Evaluate the vendor's financial stability through credit reports, financial statements, or third-party risk ratings | Finance / Procurement | Financial assessment |
| 2.6 | Verify regulatory compliance: HIPAA compliance program (if handling PHI), PCI DSS compliance (if handling payment data), applicable industry certifications | Compliance | Regulatory compliance verification |
| 2.7 | Assess vendor's business continuity and disaster recovery capabilities | IT Security / Business Owner | BC/DR review notes |
| 2.8 | Review the vendor's insurance coverage (cyber liability, errors & omissions, general liability) | Legal / Procurement | Insurance certificate review |
| 2.9 | Evaluate the vendor's incident response capabilities and notification procedures | IT Security | IR capability assessment |
| 2.10 | Compile the Vendor Risk Assessment Report with a recommendation: Approve, Approve with Conditions, or Reject | IT Security / Compliance | Vendor Risk Assessment Report |

### 5.3 Vendor Risk Assessment Scoring

| Domain | Weight | Evaluation Criteria |
|--------|--------|-------------------|
| **Data Security Controls** | 25% | Encryption (at rest/in transit), access controls, vulnerability management, logging/monitoring |
| **Compliance and Certifications** | 20% | SOC 2, ISO 27001, HITRUST, HIPAA compliance, regulatory track record |
| **Incident Response** | 15% | IR plan, breach notification SLA, breach history, forensic capability |
| **Business Continuity** | 15% | BC/DR plan, RTO/RPO, geographic redundancy, backup testing |
| **Privacy and Data Handling** | 10% | Data processing agreements, data minimization, retention/disposal, sub-processor management |
| **Financial Stability** | 10% | Credit rating, revenue stability, years in business, insurance coverage |
| **Contractual Compliance** | 5% | Willingness to accept required contract terms, audit rights, liability caps |

**Scoring:** Each domain is scored 1–5 (1=Critical Gap, 2=Significant Gap, 3=Acceptable, 4=Strong, 5=Exemplary). Weighted composite score determines approval:
- **4.0–5.0:** Approved
- **3.0–3.9:** Approved with Conditions (remediation plan required)
- **2.0–2.9:** Conditional — requires CISO and Legal approval with documented risk acceptance
- **Below 2.0:** Rejected

### 5.4 Contract Requirements

The following provisions must be included in all vendor agreements for Critical and High-tier vendors:

| Provision | Requirement |
|-----------|------------|
| **Data Protection** | Specific obligations for safeguarding organizational data; encryption standards; access restrictions |
| **Business Associate Agreement** | Required for all vendors handling PHI (HIPAA); executed before any PHI is shared |
| **Data Processing Agreement** | Required for all vendors processing PII; specifies purpose, scope, and restrictions |
| **Audit Rights** | Organization's right to audit the vendor's security and compliance controls (on-site or via third-party audit report) |
| **Breach Notification** | Vendor must notify the organization of security incidents within 24–72 hours (per regulatory requirements) |
| **Sub-processor Restrictions** | Vendor must obtain approval before engaging sub-processors; sub-processors must meet equivalent security standards |
| **Data Return/Destruction** | Upon termination, vendor must return or certifiably destroy all organizational data within 30 days |
| **Insurance** | Minimum cyber liability coverage appropriate to the engagement scope |
| **Termination Rights** | Right to terminate for cause upon material breach, including compliance failures |
| **SLA and Performance** | Defined service levels, uptime commitments, and remedies for non-performance |
| **Indemnification** | Vendor indemnifies the organization for losses arising from vendor's negligence or non-compliance |

### 5.5 Ongoing Vendor Monitoring

| Activity | Critical Tier | High Tier | Medium Tier | Low Tier |
|----------|--------------|-----------|-------------|----------|
| Security questionnaire / assessment | Annually | Annually | Biennially | At renewal |
| SOC 2 / certification review | Annually | Annually | Biennially | N/A |
| Performance / SLA review | Quarterly | Quarterly | Semi-annually | Annually |
| Financial stability check | Annually | Annually | Biennially | N/A |
| Compliance verification | Annually | Annually | Biennially | At renewal |
| Incident and breach review | Continuous | Continuous | Annually | N/A |
| On-site / virtual audit | Annually (or per contract) | As needed | N/A | N/A |
| Sub-processor review | Annually | Annually | N/A | N/A |

### 5.6 Vendor Termination and Offboarding

| Step | Action | Responsible Party | Documentation |
|------|--------|------------------|---------------|
| 6.1 | Initiate vendor termination per contract terms (notice period, termination for cause/convenience) | Business Owner / Legal | Termination notice |
| 6.2 | Notify IT Security and IAM to revoke all vendor access to organizational systems within the contractual timeline | IT Security / IAM | Access revocation log |
| 6.3 | Request vendor to return or certifiably destroy all organizational data per contract terms | Legal / Business Owner | Data return/destruction request |
| 6.4 | Obtain written confirmation of data destruction from the vendor, including method used and attestation of completeness | Legal / Compliance | Certificate of Data Destruction |
| 6.5 | Verify all access has been revoked and no residual connectivity exists | IT Security | Deprovisioning verification |
| 6.6 | Close the vendor file and archive all assessment, contract, and monitoring documentation | Records Coordinator | Archived vendor file |
| 6.7 | Update the vendor registry to reflect terminated status | Procurement | Updated registry |

## 6. Documentation Requirements

- [ ] Vendor Engagement Request Forms
- [ ] Vendor Risk Tier Assignments
- [ ] Completed Vendor Security Questionnaires
- [ ] Vendor Risk Assessment Reports (with scoring)
- [ ] Copies of vendor certifications (SOC 2, ISO 27001, etc.)
- [ ] Financial assessments
- [ ] Executed contracts, BAAs, and Data Processing Agreements
- [ ] Ongoing monitoring records (assessments, SLA reviews, audits)
- [ ] Incident records involving vendors
- [ ] Termination notices and data destruction certificates
- [ ] Vendor Registry (current)

**Retention Period:** All vendor management records must be retained for the **duration of the vendor relationship plus 6 years** after termination.

## 7. Key Performance Indicators

| Metric | Target |
|--------|--------|
| Pre-engagement assessment completion before contract execution | 100% |
| Critical/High vendor annual reassessment completion | 100% |
| BAA execution before PHI sharing | 100% |
| Vendor access revocation within contractual timeline at termination | 100% |
| Data destruction confirmation received at termination | 100% |

## 8. Related Documents

- SOP-01: Data Breach Response
- SOP-02: Access Control and Authentication
- SOP-05: Record Retention and Disposal
- Information Security Policy
- Data Classification Policy
- Procurement Policy

## 9. Review Schedule

| Review Activity | Frequency | Responsible Party |
|----------------|-----------|------------------|
| Full SOP review and update | Annually | Compliance Officer / Procurement Director |
| Vendor security questionnaire update | Annually | IT Security |
| Vendor registry audit | Semi-annually | Procurement / Compliance |
| Contract template review | Annually | Legal |

## 10. Revision History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | _____________ | _____________ | Initial release |

## 11. Approval

| Role | Name | Signature | Date |
|------|------|-----------|------|
| Compliance Officer | | | |
| CISO | | | |
| Procurement Director | | | |
| General Counsel | | | |
